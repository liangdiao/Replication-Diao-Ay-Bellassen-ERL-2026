set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

* merge dataset 
clear
use GC_crosscountry_group.dta
merge 1:1 nuts0 using  FC_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  FG_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  CG_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  CF_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  GF_crosscountry_group.dta
drop _merge
format deltasoc_* %9.1f
* rename variable. 
merge 1:1 nuts0 using "scripts/GHG Inventory/inventory_panel.dta"
replace deltasoc_FC = -12.6
replace deltasoc_CF = 43.8
replace deltasoc_FG = 4.4
replace deltasoc_GF = 30.1
rename inventory_area_GtoC  inventory_area_GC
rename inventory_area_FtoC  inventory_area_FC
rename inventory_area_FtoG  inventory_area_FG
rename inventory_area_CtoG  inventory_area_CG
rename inventory_area_CtoF  inventory_area_CF
rename inventory_area_GtoF  inventory_area_GF
rename inventory_soc_GtoC  inventory_soc_GC
rename inventory_soc_FtoC  inventory_soc_FC
rename inventory_soc_FtoG  inventory_soc_FG
rename inventory_soc_CtoG  inventory_soc_CG
rename inventory_soc_CtoF  inventory_soc_CF
rename inventory_soc_GtoF  inventory_soc_GF


foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
gen Dynamic_`x' = inventory_area_`x'*deltasoc_`x'/1000

}

* keep the same unit
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
replace inventory_soc_`x' = inventory_soc_`x'/1000
}

drop if nuts0 == "EU"

* produce table
preserve 
egen Dynamic_total = rowtotal(Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF ) 
keep nuts0 Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF Dynamic_total
fcollapse (sum) Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF Dynamic_total (first)nuts0
replace nuts0 = "EU"
save temp.dta,replace
restore

preserve 
egen Dynamic_total = rowtotal(Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF ) 
keep nuts0 Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF Dynamic_total
append using temp.dta 
export excel using "Tables/TA10.xlsx", replace firstrow(variables)
restore

preserve 
egen inventory_soc_total = rowtotal( inventory_soc_GC  inventory_soc_FC  inventory_soc_FG  inventory_soc_CG  inventory_soc_CF  inventory_soc_GF)
keep nuts0  inventory_soc_GC  inventory_soc_FC  inventory_soc_FG  inventory_soc_CG  inventory_soc_CF  inventory_soc_GF inventory_soc_total
fcollapse (sum) inventory_soc_GC  inventory_soc_FC  inventory_soc_FG  inventory_soc_CG  inventory_soc_CF  inventory_soc_GF inventory_soc_total (first)nuts0
replace nuts0 = "EU"
save temp.dta,replace
restore

preserve 
egen inventory_soc_total = rowtotal( inventory_soc_GC  inventory_soc_FC  inventory_soc_FG  inventory_soc_CG  inventory_soc_CF  inventory_soc_GF)
keep nuts0  inventory_soc_GC  inventory_soc_FC  inventory_soc_FG  inventory_soc_CG  inventory_soc_CF  inventory_soc_GF inventory_soc_total
append using temp.dta 
export excel using "Tables/TA13.xlsx", replace firstrow(variables)
restore

