*==================================================================
* R2 / R2_CG.do   --  transition CG (cropland -> grassland)
*
* Compound S1 + S4 uncertainty for the "Dynamic" estimate in Table 4.
*   S1 = CLC/ML land-cover draw (the existing bootstrap code, 1000 seeds 1001-2000)
*   S4 = sampling variance of equation (5), country prediction, aggregation
*
* CG uses the per-country, SOC-dependent prediction, so every seed is
* pushed all the way through equation (5) -> country prediction -> area
* aggregation.  For each seed s we store
*     dyn_b    = Dynamic evaluated at b_s                 (S1 variation)
*     s4var    = w_s' V_s w_s                             (S4 variance)
*     dyn_star = Dynamic evaluated at b*_s ~ N(b_s, V_s)  (compound draw)
*
* Interval cut-points are FROZEN at the main-specification values
* (0 1.5 3 4.5 6 7.5 9 10.5 12 14 15 17 20 23, then the published merges
* 15 -> 17/14 and 20 -> 23/17), so the 33 coefficients stay comparable
* across seeds.  Seed 0 reproduces T4 exactly (Dynamic_CG = 301.5257).
*
* Equation (5) is estimated exactly as published:
*     reg soc_diff_year year_passed_* year_passedXsoc_* year_passedXsoc2_*, noconstant
* with default (non-clustered) standard errors.
*
* Output: scripts/R2/R2_CG_seeds.dta
*==================================================================
set more off
clear all

global X     "CG"
global ROOT  "/Users/liang/Library/CloudStorage/Dropbox/SOC/Data analysis/Replicate"
global BOOT  "$ROOT/scripts/R2/work_CG"
global R2D   "$ROOT/scripts/R2"
global SEEDS "0 1001/2000"

cd "$ROOT"
capture mkdir "$R2D/tmp_$X"

*------------------------------------------------------------------
* frozen fine grid of time intervals
*------------------------------------------------------------------
clear
set obs 13
gen double d_start = .
gen double d_end   = .
local bounds "0 1.5 3 4.5 6 7.5 9 10.5 12 14 15 17 20 23"
local k = 0
foreach c of local bounds {
    local ++k
    if `k' < 14 {
        replace d_start = `c' in `k'
    }
    if `k' > 1 {
        replace d_end = `c' in `=`k'-1'
    }
}
drop if d_start >= 23
save "$R2D/tmp_$X/grid.dta", replace

*------------------------------------------------------------------
* loop over seeds : 0 = main specification, 1001-2000 = land-cover draws
*------------------------------------------------------------------
numlist "$SEEDS"
local seedlist "`r(numlist)'"

foreach i of local seedlist {

    * ---- (1) the seed's micro data -------------------------------
    if `i' == 0 {
        local micro "$ROOT/Lucas_derosa_${X}_cleaned.dta"
    }
    else {
        global seed = `i'
        do "$BOOT/boot_${X}.do"
        local micro "$BOOT/temp.dta"
    }
    cd "$ROOT"

    * ---- (2) equation (5) on the frozen interval grid -------------
    use "`micro'", clear
    cross using "$R2D/tmp_$X/grid.dta"
    gen start = max(0, t1 - tLUC)
    gen end   = t2 - tLUC
    keep if d_start < end & d_end > start
    replace d_end   = 17 if d_end   == 15
    replace d_start = 14 if d_start == 15
    replace d_end   = 23 if d_end   == 20
    replace d_start = 17 if d_start == 20

    local cuts "0 1.5 3 4.5 6 7.5 9 10.5 12 14 17"
    local j = 0
    foreach c of local cuts {
        local ++j
        gen year_passed_`j'      = (d_start == `c')
        gen year_passedXsoc_`j'  = soc_final*year_passed_`j'
        gen year_passedXsoc2_`j' = soc_final*soc_final*year_passed_`j'
    }
    quietly reg soc_diff_year year_passed_* year_passedXsoc_* year_passedXsoc2_*, noconstant
    local nreg = e(N)
    matrix b = e(b)
    matrix V = e(V)

    * ---- (3) per-country final SOC and transition area ------------
    use "`micro'", clear
    replace dup = 6 if dup == 2
    replace dup = 7 if dup == 3
    sort point_id dup
    by point_id: gen dupp = cond(_N==1,0,_n)
    keep if dupp <= 1
    drop if soc_final == .
    gen obs = 1
    fcollapse (mean) soc_final (sum) obs, by(nuts0)
    rename soc_final S_c
    merge 1:1 nuts0 using "$ROOT/scripts/R1/area_${X}.dta", keepusing(area_$X)
    keep if _merge == 3
    drop _merge
    rename area_$X area
    local ncty = _N

    * ---- (4) prediction, truncation, aggregation, S4 variance -----
    * one parameter draw per seed, so that the stored dyn_star is a draw
    * from the compound S1 x S4 distribution
    set seed `=710000 + `i''

    mata {
        b    = st_matrix("b")
        V    = st_matrix("V")
        nbin = 11
        mult = (J(1,8,1.5), 2, 3, 6)
        S    = st_data(., "S_c")
        area = st_data(., "area")
        nc   = rows(S)

        // b* ~ N(b, V) via the symmetric square root of V (V is p.s.d.,
        // and may be singular if a bin is empty in this seed)
        symeigensystem(V, EV=., EL=.)
        EL = EL :* (EL :> 0)
        A  = EV * diag(sqrt(EL)) * EV'
        bs = b + (A * rnormal(cols(b),1,0,1))'

        BB  = b \ bs
        res = J(2,1,0)
        w   = J(1, cols(b), 0)

        for (r=1; r<=2; r++) {
            bc = BB[r,.]
            for (cc=1; cc<=nc; cc++) {
                s    = S[cc]
                pred = J(1,nbin,0)
                for (j=1; j<=nbin; j++) {
                    pred[j] = bc[j] + bc[nbin+j]*s + bc[2*nbin+j]*s^2
                }
                yp   = J(1,nbin,0)
                kp   = J(1,nbin,0)
                yp[1] = mult[1]*pred[1]
                kp[1] = 1
                sgn      = (yp[1] >= 0 ? 1 : -1)
                prevzero = (yp[1] == 0)
                for (j=2; j<=nbin; j++) {
                    v     = mult[j]*pred[j]
                    kp[j] = 1
                    if (v*sgn < 0 | prevzero) {
                        v     = 0
                        kp[j] = 0
                    }
                    yp[j]    = v
                    prevzero = (v == 0)
                }
                f      = area[cc]/1000
                res[r] = res[r] + f*rowsum(yp)
                if (r == 1) {
                    for (j=1; j<=nbin; j++) {
                        if (kp[j] == 1) {
                            w[j]        = w[j]        + f*mult[j]
                            w[nbin+j]   = w[nbin+j]   + f*mult[j]*s
                            w[2*nbin+j] = w[2*nbin+j] + f*mult[j]*s^2
                        }
                    }
                }
            }
        }
        st_numscalar("r_dynb",  res[1])
        st_numscalar("r_dyns",  res[2])
        st_numscalar("r_s4var", (w*V*w')[1,1])
        st_numscalar("r_chk",   (w*b')[1,1])
        st_numscalar("r_nomit", sum(diagonal(V) :== 0))
    }

    * ---- (5) one row of results ----------------------------------
    clear
    set obs 1
    gen int    seed     = `i'
    gen double dyn_b    = scalar(r_dynb)
    gen double dyn_star = scalar(r_dyns)
    gen double s4var    = scalar(r_s4var)
    gen double lin_chk  = scalar(r_chk)
    gen int    nreg     = `nreg'
    gen int    ncty     = `ncty'
    gen int    nomit    = scalar(r_nomit)
    save "$R2D/tmp_$X/res_`i'.dta", replace
}

*------------------------------------------------------------------
* stack the seeds
*------------------------------------------------------------------
clear
foreach i of local seedlist {
    append using "$R2D/tmp_$X/res_`i'.dta"
}
sort seed
gen str4 cat = "$X"
order cat seed
label data "R2 CG: compound S1 x S4 draws"
save "$R2D/R2_${X}_seeds.dta", replace

di _n "==== $X : seed 0 (main spec) ===="
list cat seed dyn_b lin_chk s4var nreg ncty nomit if seed==0, noobs abbrev(12)
quietly sum dyn_b if seed!=0
di "S1 sd of dyn_b   = " %9.3f r(sd) "   (n=" r(N) ")"
quietly sum s4var if seed!=0
di "mean S4 variance = " %9.3f r(mean) "  -> S4 sd = " %9.3f sqrt(r(mean))
quietly sum dyn_star if seed!=0, detail
di "compound draws   : sd = " %9.3f r(sd) "  p2.5 = " %9.3f r(p5) "  (see compile for exact pctiles)"
