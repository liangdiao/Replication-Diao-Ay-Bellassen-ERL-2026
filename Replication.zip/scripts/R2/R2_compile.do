*==================================================================
* R2 / R2_compile.do
*
* Combines the six per-transition R2 files into the compound S1 x S4
* interval for Table 4, and decomposes the variance by stage.
*
* Inputs : scripts/R2/R2_<x>_seeds.dta   for x in GC FC FG CG CF GF
*          (seed 0 = main specification, seeds 51-150 = land-cover draws)
*
* Definitions, with s indexing the 100 land-cover draws:
*   dyn_b_{x,s}    Dynamic_x evaluated at the seed's own coefficients
*   s4var_{x,s}    sampling variance of Dynamic_x within that seed
*   dyn_star_{x,s} one draw from the compound distribution
*
* The six transitions are summed WITHIN a draw, so the correlation that
* the shared land-cover draw induces across transitions is preserved
* instead of assumed away.  The S4 draws are independent across
* transitions (each curve is estimated on a disjoint set of points), so
* the S4 variances add.
*
* Law of total variance:
*   Var(Total) = Var_s( sum_x dyn_b )      <- S1 component
*              + E_s( sum_x s4var )        <- S4 component
*
* Outputs: scripts/R2/R2_compound_CI.dta / .xlsx
*==================================================================
set more off
clear all

global ROOT "/Users/liang/Library/CloudStorage/Dropbox/SOC/Data analysis/Replicate"
global R2D  "$ROOT/scripts/R2"
cd "$ROOT"

*------------------------------------------------------------------
* stack the six transitions
*------------------------------------------------------------------
clear
foreach x in GC FC FG CG CF GF {
    append using "$R2D/R2_`x'_seeds.dta"
}
keep cat seed dyn_b dyn_star s4var
tempfile long
save `long'

*------------------------------------------------------------------
* per-transition, then the total (summed within seed)
*------------------------------------------------------------------
tempfile results
postfile pf str6 cat double point double s1_sd double s4_sd double comp_sd ///
    double s4only_lo double s4only_hi double comp_lo double comp_hi ///
    double p2_5 double p50 double p97_5 ///
    long nseed using `results', replace

foreach x in GC FC FG CG CF GF Total {

    if "`x'" == "Total" {
        use `long', clear
        collapse (sum) dyn_b dyn_star s4var, by(seed)
    }
    else {
        use `long', clear
        keep if cat == "`x'"
    }

    * point estimate = seed 0 = the published T4 value
    quietly sum dyn_b if seed == 0
    local point = r(mean)
    quietly sum s4var if seed == 0
    local s4only = sqrt(r(mean))

    drop if seed == 0
    quietly count
    local nseed = r(N)

    * S1 component : spread of the seed point estimates
    quietly sum dyn_b
    local s1_sd = r(sd)

    * S4 component : average within-seed sampling variance
    quietly sum s4var
    local s4_sd = sqrt(r(mean))

    local comp_sd = sqrt(`s1_sd'^2 + `s4_sd'^2)

    * percentile interval of the compound draws
    _pctile dyn_star, percentiles(2.5 50 97.5)
    local p2_5  = r(r1)
    local p50   = r(r2)
    local p97_5 = r(r3)

    post pf ("`x'") (`point') (`s1_sd') (`s4_sd') (`comp_sd') ///
        (`point'-1.96*`s4only') (`point'+1.96*`s4only') ///
        (`point'-1.96*`comp_sd') (`point'+1.96*`comp_sd') ///
        (`p2_5') (`p50') (`p97_5') (`nseed')
}
postclose pf

*------------------------------------------------------------------
* report
*------------------------------------------------------------------
use `results', clear
gen order = .
replace order = 1 if cat=="GC"
replace order = 2 if cat=="FC"
replace order = 3 if cat=="FG"
replace order = 4 if cat=="CG"
replace order = 5 if cat=="CF"
replace order = 6 if cat=="GF"
replace order = 7 if cat=="Total"
sort order
drop order

label var point     "Dynamic (seed 0 = T4)"
label var s1_sd     "S1 sd (land-cover draw)"
label var s4_sd     "S4 sd (eq.5 sampling)"
label var comp_sd   "Compound sd"
label var s4only_lo "S4-only 95% lo (published)"
label var s4only_hi "S4-only 95% hi (published)"
label var comp_lo   "Compound 95% lo (symmetric)"
label var comp_hi   "Compound 95% hi (symmetric)"
label var p2_5      "Compound 2.5 pctile"
label var p50       "Compound median"
label var p97_5     "Compound 97.5 pctile"
label var nseed     "Land-cover draws"

format point s1_sd s4_sd comp_sd s4only_lo s4only_hi comp_lo comp_hi p2_5 p50 p97_5 %10.2f

di _n "==== Variance decomposition, MtC ===================================="
list cat point s1_sd s4_sd comp_sd nseed, noobs sep(0) abbrev(12)
di _n "==== Intervals, MtC ================================================"
di    "     published = S4 only (delta method, land cover held fixed)"
di    "     compound  = point +/- 1.96 * compound sd  (RECOMMENDED)"
list cat point s4only_lo s4only_hi comp_lo comp_hi, noobs sep(0) abbrev(12)
di _n "==== Percentile draws, MtC (diagnostic, see README) ================"
di    "     these pass each draw through the sign-truncation recursion and are"
di    "     pulled down by truncation collapse; not the interval to report"
list cat point p2_5 p50 p97_5, noobs sep(0) abbrev(12)

save "$R2D/R2_compound_CI.dta", replace
export excel using "$R2D/R2_compound_CI.xlsx", replace firstrow(varlabels)

*------------------------------------------------------------------
* share of the compound variance coming from each stage
*------------------------------------------------------------------
gen double share_s1 = 100*s1_sd^2/comp_sd^2
gen double share_s4 = 100*s4_sd^2/comp_sd^2
format share_* %6.1f
di _n "==== Share of compound variance (%) ================================"
list cat share_s1 share_s4, noobs sep(0) abbrev(12)
