*==================================================================
* R2 / R2_FC.do   --  transition FC (forest -> cropland)
*
* Compound S1 + S4 uncertainty for the "Dynamic" estimate in Table 4.
*   S1 = CLC/ML land-cover draw, 1000 seeds (1001-2000)
*   S4 = sampling variance of the pooled response curve, aggregation
*
* FC enters T4 through a single POOLED deltasoc applied to every country.
* That constant is the LAST LINE OF TABLE 2: the sign-truncation recursion
* applied to the cumulative pooled curve of Figure 4.  Starting from the
* sign of the first segment, a segment whose contribution flips sign (or
* that follows a zeroed segment) is set to zero and the cumulation stops:
*
*   v_j  = (d_end_j - d_start_j) * mean_dSOC_j
*   v_1 kept;  sgn = sign(v_1)
*   v_j = 0  if  v_j*sgn < 0  or  v_{j-1} = 0
*   deltasoc = sum_j v_j
*
* At seed 0 this reproduces T4's constant for FC: -12.6.
* (The plain, untruncated integral does NOT -- for FC it gives -7.16,
* which is where the R1 "unreproducible -12.6" note came from.)
*
* PHASE 1 re-runs the land-cover bootstrap for each of the 1000 seeds.
* It uses scripts/R2/work_FC/boot_FC.do, a verbatim copy of
* bootstrap CLC no extra finalsoc/Lucas_ML_derosa_FC_bootstrap.do with the
* working directory redirected into work_FC/ and the relative input paths
* made absolute, so that the six transitions can run concurrently without
* competing for temp.dta.  The copy is exact: it reproduces the stored
* seed 51 byte-for-byte.
*
* PHASE 2 assembles seed 0 (main specification, from the stored file) with
* the 1000 draws, and for each seed s computes
*   dyn_b    = area_FC * deltasoc_s / 1000                    (S1 variation)
*   s4var    = (area_FC/1000)^2 * sum_j kept_j w_j^2 se_j^2   (S4 variance,
*              se_j = sd_j/sqrt(n_j); segments independent; singleton
*              segments carry no information; only kept segments enter,
*              the same convention as the w vector for GC/CG)
*   dyn_star = area_FC * deltasoc*_s / 1000, where the segment means are
*              drawn m*_j ~ N(m_j, se_j^2) and the truncation recursion is
*              RE-APPLIED to the drawn curve.  Truncation is non-linear, so
*              the draw must pass through it rather than being added as a
*              single normal on the total.  See the README on why these
*              draws are a diagnostic and not the reported interval.
*
* Output: scripts/R2/R2_FC_seeds.dta
*==================================================================
set more off
clear all

global X     "FC"
global ROOT  "/Users/liang/Library/CloudStorage/Dropbox/SOC/Data analysis/Replicate"
global R2D   "$ROOT/scripts/R2"
global BOOT  "$ROOT/scripts/R2/work_FC"
global SEEDS "1001/2000"

cd "$ROOT"
numlist "$SEEDS"
local seedlist "`r(numlist)'"

*------------------------------------------------------------------
* PHASE 1 : one land-cover draw per seed
*------------------------------------------------------------------
foreach i of local seedlist {
    global seed = `i'
    do "$BOOT/boot_${X}.do"
    cd "$ROOT"
}

*------------------------------------------------------------------
* PHASE 2 : seed 0 + the draws
*------------------------------------------------------------------
use "$ROOT/scripts/bootstrap/Lucas_ML_derosa_${X}_bt_interval.dta", clear
keep if seed == 0
tempfile main
save `main'

clear
foreach i of local seedlist {
    append using "$BOOT/seeds/${X}_seed`i'.dta"
}
append using `main'

* total transition area
preserve
use "$ROOT/scripts/R1/areas_total.dta", clear
local area = area_$X[1]
restore

gen double width = d_end - d_start
gen double se    = sd_soc_diff_year/sqrt(num_soc_diff_year)
replace    se    = 0 if missing(se)
gen byte   single = missing(sd_soc_diff_year) | num_soc_diff_year <= 1
sort seed d_start

set seed 720000
gen double z = rnormal()

mata {
    seed = st_data(., "seed")
    w    = st_data(., "width")
    m    = st_data(., "mean_soc_diff_year")
    se   = st_data(., "se")
    z    = st_data(., "z")
    n    = rows(seed)

    us  = uniqrows(seed)
    ns  = rows(us)
    out = J(ns, 7, 0)          // seed, dso, dso_star, dsovar, nseg, nkept, nkept_star

    for (r=1; r<=ns; r++) {
        idx = selectindex(seed :== us[r])
        k   = rows(idx)
        ww  = w[idx]
        mm  = m[idx]
        ss  = se[idx]
        zz  = z[idx]
        ms  = mm + ss:*zz                    // drawn segment means

        // point curve
        v1  = ww[1]*mm[1]
        sgn = (v1 >= 0 ? 1 : -1)
        prevzero = (v1 == 0)
        dso = v1
        dsv = ww[1]^2*ss[1]^2
        nkp = 1
        for (j=2; j<=k; j++) {
            v = ww[j]*mm[j]
            if (v*sgn < 0 | prevzero) {
                v = 0
            }
            else {
                dsv = dsv + ww[j]^2*ss[j]^2
                nkp = nkp + 1
            }
            dso      = dso + v
            prevzero = (v == 0)
        }

        // same recursion re-applied to the drawn curve
        dss = ww[1]*ms[1]
        sgs = (dss >= 0 ? 1 : -1)
        pzs = (dss == 0)
        nks = 1
        for (j=2; j<=k; j++) {
            v = ww[j]*ms[j]
            if (v*sgs < 0 | pzs) {
                v = 0
            }
            else {
                nks = nks + 1
            }
            dss = dss + v
            pzs = (v == 0)
        }

        out[r,1] = us[r]
        out[r,2] = dso
        out[r,3] = dss
        out[r,4] = dsv
        out[r,5] = k
        out[r,6] = nkp
        out[r,7] = nks
    }
    st_matrix("OUT", out)
}

clear
svmat double OUT, names(col)
rename c1 seed
rename c2 deltasoc
rename c3 deltasoc_star
rename c4 dsovar
rename c5 nseg
rename c6 nkept
rename c7 nkept_star

local fac = `area'/1000
gen double dyn_b    = `fac'*deltasoc
gen double dyn_star = `fac'*deltasoc_star
gen double s4var    = `fac'^2*dsovar
gen str6 cat = "$X"
order cat seed dyn_b dyn_star s4var
label data "R2 FC: compound S1 x S4 draws (Table-2 truncated pooled curve)"
save "$R2D/R2_${X}_seeds.dta", replace

di _n "==== $X : seed 0 (main spec) ===="
di "T4 / Table 2 constant = -12.6"
list cat seed deltasoc dyn_b s4var nseg nkept if seed==0, noobs abbrev(12)
quietly count if seed!=0
di "draws = " r(N)
quietly sum dyn_b if seed!=0
di "S1 sd of dyn_b   = " %9.3f r(sd)
quietly sum s4var if seed!=0
di "mean S4 variance = " %9.3f r(mean) "  -> S4 sd = " %9.3f sqrt(r(mean))
