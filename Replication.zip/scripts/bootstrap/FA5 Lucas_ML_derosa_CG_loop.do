set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate/scripts/bootstrap"


use "../../Lucas_derosa_CG_cleaned.dta"

save temp.dta,replace
gen obs = 1
fcollapse (sum)obs (first)tgrass tcrop  (mean)soc_diff_year , by(year_passed timingCG_loose t1 t2)
gen tLUC =  timingCG_loose 
rename soc_diff_year delta_soc

gen start = max(0,t1-tLUC)
gen end = t2 - tLUC
*save Lucas_derosa_CG_table_interval.dta,replace



*get all possible interval
keep start end
expand 2, gen(dup)
replace start = end if dup ==1
keep start
bysort start: gen dup = cond(_N==1,0,_n)
keep if dup <=1
drop dup
gen end = start[_n+1]
drop if end==.
gen id_segment = _n
rename start d_start 
rename end d_end
cross  using temp.dta
gen start = max(0,t1-tLUC)
gen end = t2 - tLUC

sort d_start d_end start end
gen overlap = 1 if d_start < end & d_end > start
keep if overlap == 1
keep soc_initial soc_final t2 t1 tLUC duration nuts0 soc_diff_year year_passed start end overlap d_start d_end id_segment
gen obs= 1



fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)


gen seed = 0

save Lucas_ML_derosa_CG_bt_interval.dta,replace

forvalues i = 51 / 150 {
	global seed = `i'
	* re-drawing land cover needs the raw GIS data; by default reuse the stored seeds/CG_seed*.dta
	if "$rerun_bootstrap" == "1" do Lucas_ML_derosa_CG_bootstrap.do "$seed"
	clear 
	use Lucas_ML_derosa_CG_bt_interval.dta
	append using "seeds/CG_seed`i'.dta"
	save Lucas_ML_derosa_CG_bt_interval.dta,replace
	}
	


clear
use  Lucas_ML_derosa_CG_bt_interval
gen d_middle = (d_start+d_end)/2

#delimit;
twoway (connected mean_soc_diff_year d_middle if seed !=0, lc(gs13) ms(i)  mc(gs13) lw(thin) c(L))
		(line mean_soc_diff_year d_middle if seed ==0, lc(red)   lw(thick)), 
legend(order(1 "Coef. Simulation" 2 "Coef. Main Result")) 
title("Distribution of 100 Simulations (Grassland to Forest)")
  xtitle("Years since LUC") 
  ytitle("Absolute ΔSOC (t C ha{sup:-1}year{sup:-1}) ")
  	xtitle("") xscale(r(0(2)23))  xlabel(0(2)23)
	yscale(r(-22(5)22))  ylabel(-22(5)22) 
    graphregion(color(white)) bgcolor(white) 
;
#delimit cr
graph export "../../Figures/FA5_CtoG_derosa_100sim.png",replace
