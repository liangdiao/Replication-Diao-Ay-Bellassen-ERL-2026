set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/bootstrap CLC no extra finalsoc"


use "../../GIS/Corine/Py_ML/results/Lucas_ML_combined.dta"

set seed $seed
display $seed

gen randnum_1990 = uniform()
gen randnum_2000 = uniform()
gen randnum_2006 = uniform()
gen randnum_2012 = uniform()
gen randnum_2018 = uniform()
 

gen lc1990 = "O"
replace lc1990 = ml_class1990  if randnum_1990 <= confidence1990 
gen lc2000 = "O"
replace lc2000 = ml_class2000 if randnum_2000 <= confidence2000
gen lc2006 = letter_group2006
replace lc2006 = "O" if letter_group2006 == ""
replace lc2006 = ml_class2006 if randnum_2006 <= confidence2006 & letter_group2006 == ""
gen lc2009 = letter_group2009
gen lc2012 = letter_group2012
replace lc2012 = "O" if letter_group2012 == ""
replace lc2012 = ml_class2012 if randnum_2012 <= confidence2012 & letter_group2012 == ""

gen lc2015 = letter_group2015 
gen lc2018 = letter_group2018
replace lc2018 = "O" if letter_group2018 == ""
replace lc2018 = ml_class2018 if randnum_2018 <= confidence2018 & letter_group2018 == ""

merge 1:1 point_id using "../../GIS/Workclim/Lucas_worldclim_cleaned.dta"
* all matched from master. 
drop _merge
merge 1:1 point_id using "../../GIS/BD SOC Coarse2009/Public/raster_bd.dta"
* all matched
drop _merge
merge 1:1 point_id using "../../Data analysis/join neighbour/lucas_ngbr_soc_crop_cleaned.dta"
* matched 25468
drop _merge
merge 1:1 point_id using "../../Data analysis/join neighbour/lucas_ngbr_soc_forest_cleaned.dta"
* matched 25468
drop _merge
merge 1:1 point_id using "../../Data analysis/join neighbour/lucas_ngbr_soc_grass_cleaned.dta"
* matched 25468
drop _merge

replace oc_2012 =. if oc_2012 == -999
replace clay_2009 ="" if clay_2009 == "NA"
replace sand_2009 ="" if sand_2009 == "NA"
replace caco3_2018 ="" if caco3_2018 == "NA"
replace caco3_2018 ="0" if caco3_2018 == "<  LOD"
replace caco3_2012 ="0" if caco3_2012 == "<0.5"

destring clay_2009,replace
destring sand_2009,replace
destring caco3_2018,replace
destring caco3_2012,replace



gen clay =.
replace clay = clay_2009/100 if clay_2009 !=.
replace clay = clay_2015/100 if clay_2015 !=.
replace clay = clay_2012/100 if clay_2012 !=.


gen sand =.
replace sand = sand_2009/100 if sand_2009 !=.
replace sand = sand_2015/100 if sand_2015 !=.
replace sand = sand_2012/100 if sand_2012 !=.


gen bd_2018 = 0.80806 +0.823844*exp(-0.27993*oc_2018)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2015 = 0.80806 +0.823844*exp(-0.27993*oc_2015)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2012 = 0.80806 +0.823844*exp(-0.27993*oc_2012)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2009 = 0.80806 +0.823844*exp(-0.27993*oc_2009)+(0.0014065*sand)-(0.0010299*clay)



gen coarse =.
replace coarse = coarse_2009/100 if coarse_2009 !=.
replace coarse = coarse_2015/100 if coarse_2015 !=.
replace coarse = coarse_2012/100 if coarse_2012 !=.

gen old_bd_fine_2018 = bd_2018*(1-coarse) *2.6/(2.6-bd_2018* coarse)
gen old_bd_fine_2015 = bd_2015*(1-coarse) *2.6/(2.6-bd_2015* coarse)
gen old_bd_fine_2012 = bd_2012*(1-coarse) *2.6/(2.6-bd_2012* coarse)
gen old_bd_fine_2009 = bd_2009*(1-coarse) *2.6/(2.6-bd_2009* coarse)

gen raster_bd_fine = bd_raster_1020*(1-coarse) *2.6/(2.6-bd_raster_1020* coarse)

gen old_coarse_volumn_2018 = coarse/(2.6/old_bd_fine_2018+(1-2.6/old_bd_fine_2018)*coarse)
gen old_coarse_volumn_2015 = coarse/(2.6/old_bd_fine_2015+(1-2.6/old_bd_fine_2015)*coarse)
gen old_coarse_volumn_2012 = coarse/(2.6/old_bd_fine_2012+(1-2.6/old_bd_fine_2012)*coarse)
gen old_coarse_volumn_2009 = coarse/(2.6/old_bd_fine_2009+(1-2.6/old_bd_fine_2009)*coarse)

gen coarse_volumn = coarse/(2.6/raster_bd_fine+(1-2.6/raster_bd_fine)*coarse)

*eststo all: estpost sum bd_fine_2018 bd_fine_2015 bd_fine_2012 bd_fine_2009 coarse  coarse_volumn_2018  coarse_volumn_2015    coarse_volumn_2012 coarse_volumn_2009

eststo all: estpost sum old_bd_fine_2018  coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009
estadd local obs `e(N)', replace
eststo crop: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "B" 
estadd local obs `e(N)', replace
eststo forest: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "C"
estadd local obs `e(N)', replace
eststo grass: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009      if letter_group2015 == "E" 
estadd local obs `e(N)', replace
eststo other: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "N" 
estadd local obs `e(N)', replace




*gen BD(g/cm3)*oc(gC/kg)*depth(20cm)*surface(1cm2) = soc(0.001gC/1cm2*20cm) = soc(1gC/1cm2*20cm)/1000 = soc(1tC/1ha*20cm)/1000 *100000000/1000000
gen soc_2018 = raster_bd_fine*oc_2018*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2015 = raster_bd_fine*oc_2015*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2012 = raster_bd_fine*oc_2012*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2009 = raster_bd_fine*oc_2009*20/1000*(1-coarse_volumn)*100000000/1000000

gen old_soc_2018 = old_bd_fine_2018*oc_2018*20/1000*(1-old_coarse_volumn_2018)*100000000/1000000
gen old_soc_2015 = old_bd_fine_2015*oc_2015*20/1000*(1-old_coarse_volumn_2015)*100000000/1000000
gen old_soc_2012 = old_bd_fine_2012*oc_2012*20/1000*(1-old_coarse_volumn_2012)*100000000/1000000
gen old_soc_2009 = old_bd_fine_2009*oc_2009*20/1000*(1-old_coarse_volumn_2009)*100000000/1000000

gen diff_soc_2018 = soc_2018 - old_soc_2018
gen diff_soc_2015 = soc_2015 - old_soc_2015
gen diff_soc_2012 = soc_2012 - old_soc_2012
gen diff_soc_2009 = soc_2009 - old_soc_2009

gen addition_2018 = 1 if soc_2018!=. & old_soc_2018 ==. 
gen addition_2015 = 1 if soc_2015!=. & old_soc_2015 ==. 
gen addition_2012 = 1 if soc_2012!=. & old_soc_2012 ==. 
gen addition_2009 = 1 if soc_2009!=. & old_soc_2009 ==. 

gen missing_2018 = 1 if soc_2018==. & old_soc_2018 !=. 
gen missing_2015 = 1 if soc_2015==. & old_soc_2015 !=. 
gen missing_2012 = 1 if soc_2012==. & old_soc_2012 !=. 
gen missing_2009 = 1 if soc_2009==. & old_soc_2009 !=. 

drop if oc_2009>160 & oc_2009 !=.
drop if oc_2012>160 & oc_2012 !=.
drop if oc_2015>160 & oc_2015 !=.
drop if oc_2018>160 & oc_2018 !=.

* caco3 unit is g per kg, filter and caco3 >5% (50g per kg) according to DeRosa 2023
drop if caco3_2009>50 & caco3_2009 !=.
drop if caco3_2012>50 & caco3_2012 !=.
drop if caco3_2015>50 & caco3_2015 !=.
drop if caco3_2018>50 & caco3_2018 !=.


gen count = 1
gen soc_diff1809  = soc_2018-soc_2009
gen soc_diff1815  = soc_2018-soc_2015
gen soc_diff1812  = soc_2018-soc_2012
gen soc_diff1512  = soc_2015-soc_2012
gen soc_diff1509  = soc_2015-soc_2009


gen oc_diff1809  = oc_2018-oc_2009
gen oc_diff1815  = oc_2018-oc_2015
gen oc_diff1812  = oc_2018-oc_2012
gen oc_diff1512  = oc_2015-oc_2012
gen oc_diff1509  = oc_2015-oc_2009



gen typeGF = "" 
replace typeGF = "GGGGGFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGGTGFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "TGGGGFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "TGGTGFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="C" & lc2018 =="C")

replace typeGF = "GGGGFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGGGFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "GGGTFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "TGGGFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGGTFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGGGFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGGTFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "TGGTFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")

replace typeGF = "GGGFFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="C" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGGFFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "GGGTFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "TGGFFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="C" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGGTFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGGFFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGGTFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")

replace typeGF = "GGFFFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGFFFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "GGFTFFF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF = "GGFTFTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGFFFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF = "TGFTFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")

tab typeGF
gen timingGF = .
replace timingGF = 2003  if  inlist(typeGF,"GGFFFFF","GGFTFFF")
replace timingGF = 2007.5  if  inlist(typeGF,"GGGFFFF","TGGFFFF")
replace timingGF = 2010.5  if  inlist(typeGF,"GGGGFFF","TGGGFFF")
replace timingGF = 2013.5  if  inlist(typeGF,"GGGGGFF","GGGTGFF","TGGGGFF")
replace timingGF = 2009  if  inlist(typeGF,"GGGTFFF")




gen typeGF_loose = typeGF
replace typeGF_loose = "GGGGGGF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="E" & lc2018 =="C")
replace typeGF_loose = "GGGGGTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "GGGTGGF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="E" & lc2018 =="C")
replace typeGF_loose = "TGGGGGF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="E" & lc2018 =="C")
replace typeGF_loose = "GGGTGTF" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "TGGGGTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "TGGTGGF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="E" & lc2018 =="C")
replace typeGF_loose = "TGGTGTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="" & lc2018 =="C")


replace typeGF_loose = "GFFFFFF" if (lc1990 =="E" & lc2000 =="C" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF_loose = "GFFFFTF" if (lc1990 =="E" & lc2000 =="C" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "GFFTFFF" if (lc1990 =="E" & lc2000 =="C" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF_loose = "TGFFFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF_loose = "GFFTFTF" if (lc1990 =="E" & lc2000 =="C" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "TGFFFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="C" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")
replace typeGF_loose = "TGFTFFF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="C" & lc2018 =="C")
replace typeGF_loose = "TGFTFTF" if (lc1990 =="" & lc2000 =="E" & lc2006 =="C" & lc2009 =="" & lc2012 =="C" & lc2015 =="" & lc2018 =="C")

tab typeGF_loose
gen timingGF_loose = timingGF
replace timingGF_loose = 2016.5  if  inlist(typeGF_loose,"GGGGGGF","GGGTGGF","TGGGGGF","TGGTGGF")
replace timingGF_loose = 2015  if  inlist(typeGF_loose,"GGGGGTF","GGGTGTF","TGGGGTF","TGGTGTF")
replace timingGF_loose = 1995  if  inlist(typeGF_loose,"GFFFFFF","GFFFFTF","GFFTFFF","GFFTFTF")
replace timingGF_loose = 2003  if  inlist(typeGF_loose,"TGFFFFF","TGFFFTF","TGFTFFF","TGFTFTF")


gen tgrass = 1990 if (lc1990 == "E")
replace tgrass = 2000 if (lc2000 == "E")
replace tgrass = 2006 if (lc2006 == "E")
replace tgrass = 2009 if (lc2009 == "E")
replace tgrass = 2012 if (lc2012 == "E")
replace tgrass = 2015 if (lc2015 == "E")
replace tgrass = 2018 if (lc2018 == "E")
replace tgrass = . if typeGF_loose == ""

gen tforest = 2018 if (lc2018 == "C")
replace tforest = 2015 if (lc2015 == "C")
replace tforest = 2012 if (lc2012 == "C")
replace tforest = 2009 if (lc2009 == "C")
replace tforest = 2006 if (lc2006 == "C")
replace tforest = 2000 if (lc2000 == "C")
replace tforest = 1990 if (lc1990 == "C")
replace tforest = . if typeGF_loose == ""
capture drop timingGF_loose
gen timingGF_loose = (tforest + tgrass)/2









gen typeGG = ""
replace typeGG = "AGGAGAG" if (inlist(lc1990,"","B") & lc2000 =="B" & lc2006 =="B" & inlist(lc2009,"B","") & lc2012 =="B" & inlist(lc2015,"","B") & lc2018 =="B")


gen typeCC = ""
replace typeCC= "ACCACAC" if (inlist(lc1990,"","E") & lc2000 =="E" & lc2006 =="E" & inlist(lc2009,"E","") & lc2012 =="E" & inlist(lc2015,"","E") & lc2018 =="E")

gen typeFF = ""
replace typeFF = "AFFAFAF" if (inlist(lc1990,"","C") & lc2000 =="C" & lc2006 =="C" & inlist(lc2009,"C","") & lc2012 =="C" & inlist(lc2015,"","C") & lc2018 =="C")


gen tLUC = timingGF_loose 

drop if typeGF_loose == ""

expand 5
bysort point_id: gen dup = cond(_N==1,0,_n)



gen soc_diff = soc_2018-soc_2015 if dup == 1
gen soc_final = soc_2018 if dup == 1
gen soc_initial = soc_2015 if dup == 1
gen t2 = 2018 if dup == 1
gen t1 = 2015 if dup == 1

replace soc_diff = soc_2015-soc_2012 if dup == 2
replace soc_final = soc_2015 if dup == 2
replace soc_initial = soc_2012 if dup == 2
replace t2 = 2015 if dup == 2
replace t1 = 2012 if dup == 2


replace soc_diff = soc_2015-soc_2009 if dup == 3
replace soc_final = soc_2015 if dup == 3
replace soc_initial = soc_2009 if dup == 3
replace t2 = 2015 if dup == 3
replace t1 = 2009 if dup == 3


replace soc_diff = soc_2018-soc_2009 if dup == 4 & soc_2015 ==.
replace soc_final = soc_2018 if dup == 4 & soc_2015 ==.
replace soc_initial = soc_2009 if dup == 4 & soc_2015 ==.
replace t2 = 2018 if dup == 4 & soc_2015 ==.
replace t1 = 2009 if dup == 4 & soc_2015 ==.


replace soc_diff = soc_2018-soc_2012 if dup == 5 & soc_2015 ==.
replace soc_final = soc_2018 if dup == 5 & soc_2015 ==.
replace soc_initial = soc_2012 if dup == 5 & soc_2015 ==.
replace t2 = 2018 if dup == 5 & soc_2015 ==.
replace t1 = 2012 if dup == 5 & soc_2015 ==.

drop if soc_diff ==.
replace t1 = tLUC if t1 < tLUC & tLUC < t2
drop if tLUC >=t2

replace soc_initial = ngbr_grass_soc if tLUC<t1 


gen duration = t2 -t1
gen soc_diff_year = soc_diff/duration

gen year_passed = max((t1+t2)/2-tLUC,(tLUC+t2)/2-tLUC)

*fcollapse (mean)soc_diff duration (sum) count, by(t1 t2 tLUC)

save temp.dta,replace


gen obs = 1
fcollapse (sum)obs (first)tgrass tforest  (mean)soc_diff_year , by(year_passed timingGF_loose t1 t2)
gen tLUC =  timingGF_loose 
rename soc_diff_year delta_soc

gen start = max(0,t1-tLUC)
gen end = t2 - tLUC
*save Lucas_derosa_GF_table_interval.dta,replace



*get all possible interval
keep start end
expand 2, gen(dup)
replace start = end if dup ==1
keep start
bysort start: gen dup = cond(_N==1,0,_n)
keep if dup <=1
drop dup
gen end = start[_n+1]
drop if end==.
gen id_segment = _n
rename start d_start 
rename end d_end
cross  using temp.dta
gen start = max(0,t1-tLUC)
gen end = t2 - tLUC

sort d_start d_end start end
gen overlap = 1 if d_start < end & d_end > start
keep if overlap == 1
keep soc_initial soc_final t2 t1 tLUC duration nuts0 soc_diff_year year_passed start end overlap d_start d_end id_segment
gen obs= 1

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)

gen seed = $seed
local seed =$seed
save "seeds/GF_seed`seed'.dta", replace




