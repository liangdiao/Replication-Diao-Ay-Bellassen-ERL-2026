set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

* Inputs expected in this folder besides Lucas_ML_merged.dta:
*   Lucas_ML_derosa_nochange.dta              (scripts/B/Lucas_ML_derosa_clean.do, needs raw GIS data)
*   Lucas_cross_crop/grass/forest.dta         (static cross-section, built outside this folder)
*   LUC_data.xlsx                             (Table 4, national GHG inventories)

clear
* Table 1: plots without land-use change
run "scripts/A/T1 Lucas_ML_derosa_CCGGFF_clean"

* Figure A1, Tables A2-A7 + Figure A3 (merged intervals), Figure 4 + Figure A2 (non-merged intervals)
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{	
	run "scripts/A/FA1 Lucas_ML_derosa_`x'_clean"
	local ta = cond("`x'"=="CG",2,cond("`x'"=="GC",3,cond("`x'"=="CF",4,cond("`x'"=="FC",5,cond("`x'"=="FG",6,7)))))
	run "scripts/A/FA3 TA`ta' Lucas_ML_derosa_`x'_interval"
	run "scripts/A/F4 FA2 T2 Lucas_ML_derosa_`x'_interval_nonmerged"
}

* Figure A4, Figures A6-A9
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{	
	run "scripts/A/FA4 FA6-FA9 Lucas_ML_derosa_crosstable_`x'_interval"
}

run "scripts/B/T1"
run "scripts/A/T2 Lucas_cumulative_table"
run "scripts/A/T3 Lucas_ML_derosa_CF_interval resampling"
run "scripts/A/T3 Lucas_ML_derosa_interval_summary"

* Tables A8, A9, A11, A12 (these also build *_crosscountry_group.dta used by Table 4 and A10)
run "scripts/B/TA9 Lucas_ML_derosa_crosstable_compile"
run "scripts/B/TA8 TA11 TA12 Lucas_ML_derosa_crosstable_compile"
run "scripts/B/T4 Lucas_ML_derosa_GHG_inventory_clean"
run "scripts/GHG Inventory/TA10 TA13 Lucas_ML_derosa_GHG_inventory_clean"

* Table 4: compound 95% CI (combines the stored scripts/R2/R2_<x>_seeds.dta)
run "scripts/R2/R2_compile"

* Figure A11
run "scripts/other/FA11 representation_country"

* Figure A5 (bootstrap)
* set to 1 to re-draw the 100 land-cover seeds from raw GIS data (outside this folder)
global rerun_bootstrap 0
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
	* each loop script changes the working directory to scripts/bootstrap, so return to Replicate first
	cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"
	run "scripts/bootstrap/FA5 Lucas_ML_derosa_`x'_loop"
}
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"
