set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

* Table 3: Comparison of cumulative dSOC across LUCs
* Inputs (run these first):
*   Lucas_derosa_XX_clean_interval_nonmerged.dta  scripts/A/F4 FA2 T2 Lucas_ML_derosa_XX_interval_nonmerged.do
*   XX_soc_cumulative.dta                         same scripts (the Table 2 curve, truncated at equilibrium)
*   soc_EU_XX.dta                                 scripts/A/T3 Lucas_ML_derosa_CF_interval resampling.do (1000 bootstrap draws)
* The "inventories" and "Poeplau et al. (2011)" columns of Table 3 are not produced here.

tempfile t3 a b
clear
gen str2 LUC = ""
save `t3'

foreach x in "CF" "CG" "GF" "FG" "FC" "GC" {
	* Initial SOC: mean SOC of the first LUCAS sample over the interval-level observations
	use Lucas_derosa_`x'_clean_interval_nonmerged.dta, clear
	collapse (mean) initial_soc = soc_initial
	save `a', replace

	* 95% confidence interval half-width: 1.96 x SD of the bootstrap draws
	use soc_EU_`x'.dta, clear
	keep if seed > 0
	collapse (sd) sd = soc_interval_`x'
	gen dsoc_ci = 1.96*sd
	drop sd
	save `b', replace

	* Cumulative dSOC and equilibrium time: last line of Table 2
	* (for CF and GF no reversal is observed, so the equilibrium time is ">= 23")
	use `x'_soc_cumulative.dta, clear
	sort d_end
	keep if _n == _N
	rename d_end equilibrium_time
	rename cumul_`x' dsoc
	keep equilibrium_time dsoc
	cross using `a'
	cross using `b'
	gen LUC = "`x'"
	append using `t3'
	save `t3', replace
}

use `t3', clear
* percentage change relative to initial SOC, and its confidence interval
gen pct_dsoc = 100*dsoc/initial_soc
gen pct_dsoc_ci = 100*dsoc_ci/initial_soc
gen order = strpos("CF CG GF FG FC GC", LUC)
sort order
drop order
order LUC initial_soc equilibrium_time dsoc dsoc_ci pct_dsoc pct_dsoc_ci
format initial_soc dsoc %9.1f
format dsoc_ci %9.2f
format pct_dsoc pct_dsoc_ci %9.0f
list, noobs abbreviate(16)
* Table 3: initial SOC (tC/ha), equilibrium time (years), dSOC +/- 95% CI (tC/ha), %dSOC +/- 95% CI
export excel using "Tables/T3.xlsx", replace firstrow(variables)
