set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

clear
use Lucas_ML_merged.dta

* Replace invalid or missing data with appropriate values
replace oc_2012 =. if oc_2012 == -999
replace clay_2009 ="" if clay_2009 == "NA"
replace sand_2009 ="" if sand_2009 == "NA"
replace caco3_2018 ="" if caco3_2018 == "NA"
replace caco3_2018 ="0" if caco3_2018 == "<  LOD"
replace caco3_2012 ="0" if caco3_2012 == "<0.5"

destring clay_2009,replace
destring sand_2009,replace
destring caco3_2018,replace
destring caco3_2012,replace


* Create and calculate new variables for clay and sand percentages
gen clay =.
replace clay = clay_2009/100 if clay_2009 !=.
replace clay = clay_2015/100 if clay_2015 !=.
replace clay = clay_2012/100 if clay_2012 !=.


gen sand =.
replace sand = sand_2009/100 if sand_2009 !=.
replace sand = sand_2015/100 if sand_2015 !=.
replace sand = sand_2012/100 if sand_2012 !=.

* Calculate bulk density for different years using a specified formula
gen bd_2018 = 0.80806 +0.823844*exp(-0.27993*oc_2018)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2015 = 0.80806 +0.823844*exp(-0.27993*oc_2015)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2012 = 0.80806 +0.823844*exp(-0.27993*oc_2012)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2009 = 0.80806 +0.823844*exp(-0.27993*oc_2009)+(0.0014065*sand)-(0.0010299*clay)



gen coarse =.
replace coarse = coarse_2009/100 if coarse_2009 !=.
replace coarse = coarse_2015/100 if coarse_2015 !=.
replace coarse = coarse_2012/100 if coarse_2012 !=.

gen old_bd_fine_2018 = bd_2018*(1-coarse) *2.6/(2.6-bd_2018* coarse)
gen old_bd_fine_2015 = bd_2015*(1-coarse) *2.6/(2.6-bd_2015* coarse)
gen old_bd_fine_2012 = bd_2012*(1-coarse) *2.6/(2.6-bd_2012* coarse)
gen old_bd_fine_2009 = bd_2009*(1-coarse) *2.6/(2.6-bd_2009* coarse)

gen raster_bd_fine = bd_raster_1020*(1-coarse) *2.6/(2.6-bd_raster_1020* coarse)

gen old_coarse_volumn_2018 = coarse/(2.6/old_bd_fine_2018+(1-2.6/old_bd_fine_2018)*coarse)
gen old_coarse_volumn_2015 = coarse/(2.6/old_bd_fine_2015+(1-2.6/old_bd_fine_2015)*coarse)
gen old_coarse_volumn_2012 = coarse/(2.6/old_bd_fine_2012+(1-2.6/old_bd_fine_2012)*coarse)
gen old_coarse_volumn_2009 = coarse/(2.6/old_bd_fine_2009+(1-2.6/old_bd_fine_2009)*coarse)

gen coarse_volumn = coarse/(2.6/raster_bd_fine+(1-2.6/raster_bd_fine)*coarse)

*eststo all: estpost sum bd_fine_2018 bd_fine_2015 bd_fine_2012 bd_fine_2009 coarse  coarse_volumn_2018  coarse_volumn_2015    coarse_volumn_2012 coarse_volumn_2009

eststo all: estpost sum old_bd_fine_2018  coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009
estadd local obs `e(N)', replace
eststo crop: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "B" 
estadd local obs `e(N)', replace
eststo forest: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "C"
estadd local obs `e(N)', replace
eststo grass: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009      if letter_group2015 == "E" 
estadd local obs `e(N)', replace
eststo other: estpost sum old_bd_fine_2018 old_bd_fine_2015 old_bd_fine_2012 old_bd_fine_2009 coarse  old_coarse_volumn_2018  old_coarse_volumn_2015    old_coarse_volumn_2012 old_coarse_volumn_2009     if letter_group2015 == "N" 
estadd local obs `e(N)', replace




*gen BD(g/cm3)*oc(gC/kg)*depth(20cm)*surface(1cm2) = soc(0.001gC/1cm2*20cm) = soc(1gC/1cm2*20cm)/1000 = soc(1tC/1ha*20cm)/1000 *100000000/1000000
gen soc_2018 = raster_bd_fine*oc_2018*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2015 = raster_bd_fine*oc_2015*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2012 = raster_bd_fine*oc_2012*20/1000*(1-coarse_volumn)*100000000/1000000
gen soc_2009 = raster_bd_fine*oc_2009*20/1000*(1-coarse_volumn)*100000000/1000000

gen old_soc_2018 = old_bd_fine_2018*oc_2018*20/1000*(1-old_coarse_volumn_2018)*100000000/1000000
gen old_soc_2015 = old_bd_fine_2015*oc_2015*20/1000*(1-old_coarse_volumn_2015)*100000000/1000000
gen old_soc_2012 = old_bd_fine_2012*oc_2012*20/1000*(1-old_coarse_volumn_2012)*100000000/1000000
gen old_soc_2009 = old_bd_fine_2009*oc_2009*20/1000*(1-old_coarse_volumn_2009)*100000000/1000000

gen diff_soc_2018 = soc_2018 - old_soc_2018
gen diff_soc_2015 = soc_2015 - old_soc_2015
gen diff_soc_2012 = soc_2012 - old_soc_2012
gen diff_soc_2009 = soc_2009 - old_soc_2009

gen addition_2018 = 1 if soc_2018!=. & old_soc_2018 ==. 
gen addition_2015 = 1 if soc_2015!=. & old_soc_2015 ==. 
gen addition_2012 = 1 if soc_2012!=. & old_soc_2012 ==. 
gen addition_2009 = 1 if soc_2009!=. & old_soc_2009 ==. 

gen missing_2018 = 1 if soc_2018==. & old_soc_2018 !=. 
gen missing_2015 = 1 if soc_2015==. & old_soc_2015 !=. 
gen missing_2012 = 1 if soc_2012==. & old_soc_2012 !=. 
gen missing_2009 = 1 if soc_2009==. & old_soc_2009 !=. 

* Drop observations where organic carbon (oc) exceeds an upper limit of 160

drop if oc_2009>160 & oc_2009 !=.
drop if oc_2012>160 & oc_2012 !=.
drop if oc_2015>160 & oc_2015 !=.
drop if oc_2018>160 & oc_2018 !=.

* caco3 unit is g per kg, filter and caco3 >5% (50g per kg) according to DeRosa 2023
drop if caco3_2009>50 & caco3_2009 !=.
drop if caco3_2012>50 & caco3_2012 !=.
drop if caco3_2015>50 & caco3_2015 !=.
drop if caco3_2018>50 & caco3_2018 !=.

* Calculate differences in Soil Organic Carbon (SOC) between various years
gen count = 1
gen soc_diff1809  = soc_2018-soc_2009
gen soc_diff1815  = soc_2018-soc_2015
gen soc_diff1812  = soc_2018-soc_2012
gen soc_diff1512  = soc_2015-soc_2012
gen soc_diff1509  = soc_2015-soc_2009


gen oc_diff1809  = oc_2018-oc_2009
gen oc_diff1815  = oc_2018-oc_2015
gen oc_diff1812  = oc_2018-oc_2012
gen oc_diff1512  = oc_2015-oc_2012
gen oc_diff1509  = oc_2015-oc_2009


* Generate a new variable 'typeGC' to classify land-use change (LUC) patterns

gen typeGC = "" 
replace typeGC = "GGGGGCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGGTGCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "TGGGGCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "TGGTGCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="B" & lc2018 =="B")

replace typeGC = "GGGGCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGGGCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "GGGTCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "TGGGCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGGTCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGGGCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGGTCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "TGGTCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")

replace typeGC = "GGGCCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="B" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGGCCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "GGGTCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "TGGCCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="B" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGGTCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGGCCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGGTCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")

replace typeGC = "GGCCCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGCCCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "GGCTCCC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC = "GGCTCTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGCCCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC = "TGCTCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")

* Create a new variable 'timingGC' to capture the timing of LUC
tab typeGC
gen timingGC = .
replace timingGC = 2003  if  inlist(typeGC,"GGCCCCC","GGCTCCC")
replace timingGC = 2007.5  if  inlist(typeGC,"GGGCCCC","TGGCCCC")
replace timingGC = 2010.5  if  inlist(typeGC,"GGGGCCC","TGGGCCC")
replace timingGC = 2013.5  if  inlist(typeGC,"GGGGGCC","GGGTGCC","TGGGGCC")
replace timingGC = 2009  if  inlist(typeGC,"GGGTCCC")



* Generate a 'loose' classification of LUC types
gen typeGC_loose = typeGC
replace typeGC_loose = "GGGGGGC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="E" & lc2018 =="B")
replace typeGC_loose = "GGGGGTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "GGGTGGC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="E" & lc2018 =="B")
replace typeGC_loose = "TGGGGGC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="E" & lc2018 =="B")
replace typeGC_loose = "GGGTGTC" if (lc1990 =="E" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "TGGGGTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="E" & lc2012 =="E" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "TGGTGGC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="E" & lc2018 =="B")
replace typeGC_loose = "TGGTGTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="E" & lc2009 =="" & lc2012 =="E" & lc2015 =="" & lc2018 =="B")


replace typeGC_loose = "GCCCCCC" if (lc1990 =="E" & lc2000 =="B" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC_loose = "GCCCCTC" if (lc1990 =="E" & lc2000 =="B" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "GCCTCCC" if (lc1990 =="E" & lc2000 =="B" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC_loose = "TGCCCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC_loose = "GCCTCTC" if (lc1990 =="E" & lc2000 =="B" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "TGCCCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="B" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")
replace typeGC_loose = "TGCTCCC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="B" & lc2018 =="B")
replace typeGC_loose = "TGCTCTC" if (lc1990 =="" & lc2000 =="E" & lc2006 =="B" & lc2009 =="" & lc2012 =="B" & lc2015 =="" & lc2018 =="B")

* Assign timing values for the loose classification
tab typeGC_loose
gen timingGC_loose = timingGC
replace timingGC_loose = 2016.5  if  inlist(typeGC_loose,"GGGGGGC","GGGTGGC","TGGGGGC","TGGTGGC")
replace timingGC_loose = 2015  if  inlist(typeGC_loose,"GGGGGTC","GGGTGTC","TGGGGTC","TGGTGTC")
replace timingGC_loose = 1995  if  inlist(typeGC_loose,"GCCCCCC","GCCCCTC","GCCTCCC","GCCTCTC")
replace timingGC_loose = 2003  if  inlist(typeGC_loose,"TGCCCCC","TGCCCTC","TGCTCCC","TGCTCTC")

* Generate variables for the timing of grassland (tgrass) and cropland (tcrop)
gen tgrass = 1990 if (lc1990 == "E")
replace tgrass = 2000 if (lc2000 == "E")
replace tgrass = 2006 if (lc2006 == "E")
replace tgrass = 2009 if (lc2009 == "E")
replace tgrass = 2012 if (lc2012 == "E")
replace tgrass = 2015 if (lc2015 == "E")
replace tgrass = 2018 if (lc2018 == "E")
replace tgrass = . if typeGC_loose == ""

gen tcrop = 2018 if (lc2018 == "B")
replace tcrop = 2015 if (lc2015 == "B")
replace tcrop = 2012 if (lc2012 == "B")
replace tcrop = 2009 if (lc2009 == "B")
replace tcrop = 2006 if (lc2006 == "B")
replace tcrop = 2000 if (lc2000 == "B")
replace tcrop = 1990 if (lc1990 == "B")
replace tcrop = . if typeGC_loose == ""
* Calculate the mid-point for the timing of land-use change
capture drop timingGC_loose
gen timingGC_loose = (tcrop + tgrass)/2





* Assign the "AGGAGAG" pattern for transitions involving grassland (E) persistence across specified years

gen typeGG = ""
replace typeGG = "AGGAGAG" if (inlist(lc1990,"","E") & lc2000 =="E" & lc2006 =="E" & inlist(lc2009,"E","") & lc2012 =="E" & inlist(lc2015,"","E") & lc2018 =="E")

* Assign the "ACCACAC" pattern for transitions involving cropland (B) persistence across specified years

gen typeCC = ""
replace typeCC= "ACCACAC" if (inlist(lc1990,"","B") & lc2000 =="B" & lc2006 =="B" & inlist(lc2009,"B","") & lc2012 =="B" & inlist(lc2015,"","B") & lc2018 =="B")
* Generate variable 'typeFF' to classify forest (C) persistence across specified years

gen typeFF = ""
replace typeFF = "AFFAFAF" if (inlist(lc1990,"","C") & lc2000 =="C" & lc2006 =="C" & inlist(lc2009,"C","") & lc2012 =="C" & inlist(lc2015,"","C") & lc2018 =="C")

* Assign the timing of land-use change (LUC) based on the 'timingGC_loose' variable


gen tLUC = timingGC_loose 

* Drop observations where 'typeGC_loose' is missing or undefined


drop if typeGC_loose == ""

save temp.dta,replace



clear
use temp.dta
* Create a histogram to visualize the timing of LUC from Grassland to Cropland

#delimit;
hist timingGC_loose ,frequency bcolor("blue") width(0.01)  barwidth(1)
  title("Timing of LUC Grassland to Cropland")
  xtitle("Year of Land Use Change") 
  ytitle("Number of Observations")
      yscale(r(0(100)450)) ylabel(0(100)450) 
	  xlabel(1995 2003 2007.5 2009 2010.5 2013.5 2016.5, alternate )  

  graphregion(color(white)) bgcolor(white)
        text(380 2008 "N(LUC GC) = 638", placement(ne) color(black) size(large))
  text(350 2008 "N(ΔSOC GC) = 1860", placement(ne) color(black) size(large))
  ;
#delimit cr
graph export "Figures/FA1_GtoC_derosa_soc_timing.png",replace




clear
use temp.dta
* Expand the dataset to allow for multiple duplicate observations per point_id
expand 5
bysort point_id: gen dup = cond(_N==1,0,_n)

* Calculate SOC differences, final values, initial values, and time periods for the first duplicate (2018-2015)


gen soc_diff = soc_2018-soc_2015 if dup == 1
gen oc_diff = oc_2018-oc_2015 if dup == 1
gen soc_final = soc_2018 if dup == 1
gen soc_initial = soc_2015 if dup == 1
gen t2 = 2018 if dup == 1
gen t1 = 2015 if dup == 1
* Calculate SOC differences, final values, initial values, and time periods for the second duplicate (2015-2012)

replace soc_diff = soc_2015-soc_2012 if dup == 2
replace oc_diff = oc_2015-oc_2012 if dup == 2
replace soc_final = soc_2015 if dup == 2
replace soc_initial = soc_2012 if dup == 2
replace t2 = 2015 if dup == 2
replace t1 = 2012 if dup == 2

* Calculate SOC differences, final values, initial values, and time periods for the third duplicate (2015-2009)

replace soc_diff = soc_2015-soc_2009 if dup == 3
replace oc_diff = oc_2015-oc_2009 if dup == 3
replace soc_final = soc_2015 if dup == 3
replace soc_initial = soc_2009 if dup == 3
replace t2 = 2015 if dup == 3
replace t1 = 2009 if dup == 3

* Handle cases where 2015 data is missing and calculate SOC differences for the fourth duplicate (2018-2009)

replace soc_diff = soc_2018-soc_2009 if dup == 4 & soc_2015 ==.
replace oc_diff = oc_2018-oc_2009 if dup == 4 & soc_2015 ==.
replace soc_final = soc_2018 if dup == 4 & soc_2015 ==.
replace soc_initial = soc_2009 if dup == 4 & soc_2015 ==.
replace t2 = 2018 if dup == 4 & soc_2015 ==.
replace t1 = 2009 if dup == 4 & soc_2015 ==.

* Handle cases where 2015 data is missing and calculate SOC differences for the fifth duplicate (2018-2012)

replace soc_diff = soc_2018-soc_2012 if dup == 5 & soc_2015 ==.
replace oc_diff = oc_2018-oc_2012 if dup == 5 & soc_2015 ==.
replace soc_final = soc_2018 if dup == 5 & soc_2015 ==.
replace soc_initial = soc_2012 if dup == 5 & soc_2015 ==.
replace t2 = 2018 if dup == 5 & soc_2015 ==.
replace t1 = 2012 if dup == 5 & soc_2015 ==.

* Drop observations where SOC differences could not be calculated

drop if soc_diff ==.
* Adjust t1 to match the timing of land-use change (tLUC) if it falls within the range of t1 and t2
* Drop observations where land-use change timing (tLUC) occurs after t2
replace t1 = tLUC if t1 < tLUC & tLUC < t2
drop if tLUC >=t2


* Calculate the duration of time intervals
* Calculate the annual SOC difference

 
gen duration = t2 -t1
gen soc_diff_year = soc_diff/duration
* annual change in organic carbon content (g C/kg per year), used for Figure A2
gen oc_diff_year = oc_diff/duration
* Calculate the years passed since the land-use change using the midpoint of t1, t2, and tLUC

gen year_passed = max((t1+t2)/2-tLUC,(tLUC+t2)/2-tLUC)

sort year_passed
save Lucas_derosa_GC_cleaned.dta,replace



* Create a scatter plot with confidence intervals and labeled observation counts
*title("Grassland to Cropland")
clear
use Lucas_derosa_GC_cleaned.dta

collapse  (count)num_soc_diff_year = soc_diff_year  (mean) mean_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year, by(year_passed)

gen lb_soc_diff_year = mean_soc_diff_year - 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))
gen ub_soc_diff_year = mean_soc_diff_year + 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))

gen pos1 = 12
gen obs_soc = string(num_soc_diff_year, "%2.0f")


#delimit;
twoway (scatter mean_soc_diff_year year_passed ,
ymla(12 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_soc_diff_year ub_soc_diff_year year_passed)
	   (scatter pos1  year_passed, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  
  xtitle(" Years Passed since Land Use Change")
  ytitle("Absolute ΔSOC (t C ha{sup:-1}year{sup:-1}) ")
  yscale(r(-16(5)14))  ylabel(-15(5)10)
   xlabel(,labsize(normalsize))
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "Figures/GtoC_derosa_soc_raw.png",replace



