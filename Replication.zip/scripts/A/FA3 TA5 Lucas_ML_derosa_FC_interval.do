set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"





clear
use Lucas_derosa_FC_cleaned
gen obs = 1
fcollapse (sum)obs (first)tforest tcrop  (mean)soc_diff_year , by(year_passed timingFC_loose t1 t2)
gen tLUC = timingFC_loose 
rename soc_diff_year delta_soc

gen start = max(0,t1-tLUC)
gen end = t2 - tLUC
*save Lucas_derosa_FC_table_interval.dta,replace



*get all possible interval
keep start end
expand 2, gen(dup)
replace start = end if dup ==1
keep start
bysort start: gen dup = cond(_N==1,0,_n)
keep if dup <=1
drop dup
gen end = start[_n+1]
drop if end==.
gen id_segment = _n
rename start d_start 
rename end d_end
cross  using Lucas_derosa_FC_cleaned.dta
gen start = max(0,t1-tLUC)
gen end = t2 - tLUC

sort d_start d_end start end
gen overlap = 1 if d_start < end & d_end > start
keep if overlap == 1
keep soc_initial soc_final t2 t1 tLUC duration nuts0 soc_diff_year year_passed start end overlap d_start d_end id_segment
gen obs= 1






tab d_start
* merged obs <=50
replace d_end = 3 if d_end == 1.5
replace d_start = 0 if d_start == 1.5


replace d_end = 23 if d_end == 15
replace d_start = 14 if d_start == 15
replace d_end = 23 if d_end == 17
replace d_start = 14 if d_start == 17
replace d_end = 23 if d_end == 20
replace d_start = 14 if d_start == 20


gen year_passed_1 = 0 
replace year_passed_1 = 1 if d_start == 0
gen year_passed_2 = 0 
replace year_passed_2 = 1 if d_start == 3
gen year_passed_3 = 0 
replace year_passed_3 = 1 if d_start == 4.5
gen year_passed_4 = 0 
replace year_passed_4 = 1 if d_start == 6
gen year_passed_5 = 0 
replace year_passed_5 = 1 if d_start == 7.5
gen year_passed_6 = 0 
replace year_passed_6 = 1 if d_start == 9
gen year_passed_7 = 0 
replace year_passed_7 = 1 if d_start == 10.5
gen year_passed_8 = 0 
replace year_passed_8 = 1 if d_start == 12
gen year_passed_9 = 0 
replace year_passed_9 = 1 if d_start == 14


forval i = 1(1)9 {
	gen year_passedXsoc_`i' = soc_final * year_passed_`i' 
	}
forval i = 1(1)9 {
	gen year_passedXsoc2_`i' = soc_final * soc_final * year_passed_`i'
	}
	
	
save Lucas_derosa_FC_clean_interval.dta,replace


forval i = 1(1)9 {
	gen var`i' = year_passed_`i'
}

eststo c1: reg soc_diff_year var* year_passedXsoc_* year_passedXsoc2_* , noconstant
estadd local r2 "", replace

forval i = 1(1)9 {
	replace var`i' = year_passedXsoc_`i'
}
eststo c2: reg soc_diff_year year_passed_* var* year_passedXsoc2_* , noconstant
estadd local r2 "", replace

forval i = 1(1)9 {
	replace var`i' = year_passedXsoc2_`i'
}
eststo c3: reg soc_diff_year year_passed_* year_passedXsoc_* var* , noconstant
estadd local r2 `=round(e(r2),0.01)', replace
estadd local obs `e(N)', replace
* re-store c3: otherwise esttab keeps only the first statistic added (R2) and the Observations row is blank
eststo c3
sum soc_diff_year




label variable  var1 "Year Passed 0     - 3"
label variable  var2 "Year Passed 3  - 4.5"
label variable  var3 "Year Passed 4.5  - 6"
label variable  var4 "Year Passed 6     - 7.5"
label variable  var5 "Year Passed 7.5  - 9"
label variable  var6 "Year Passed 9     - 10.5"
label variable  var7 "Year Passed 10.5 - 12"
label variable  var8 "Year Passed 12      - 14"
label variable  var9 "Year Passed 14     - 23"


#delimit ;
esttab c1 c2 c3  using "Tables/TA5_FtoC_derosa_diff_interval.tex",replace  star(* 0.10 ** 0.05 *** 0.01) 
cells(b(star fmt(%09.3g)) se(par fmt(%09.3g))) 
keep(   var*)
coeflabels( oc_initial "Initial SOC" soc_final "Final SOC" clay "Clay" 
sand "Sand" temp_avg "Mean Temperature" prec_total "Total Precipitation" 
prec_std "Std. Precipitation" temp_std "Std. Temperature") 
s(   r2   obs   , 
label(   "R\$^2\$"  "Observations" )) 
 prehead("\hline\hline Dependent Variable: & \multicolumn{3}{c}{Absolute change in SOC} \\ ") 
 postfoot("")
 collabels(none) mlabels("No X" "X SOC " "X SOC\$^2\$" "X Avg.Temp" "X Total. Prec")  nodepvars eqlabels(none) 
 label lines substitute(\_ _) se booktabs ; 
#delimit cr





preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)
egen total_soc = sum((d_end-d_start)*mean_soc_diff_year)
restore


preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)

gen lb_soc_diff_year = mean_soc_diff_year - 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))
gen ub_soc_diff_year = mean_soc_diff_year + 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))


gen pos1 = 9
gen obs_soc = string(num_soc_diff_year, "%2.0f")
gen d_middle = (d_start+d_end)/2
insobs 1
replace d_start = 23 if d_start ==.
#delimit;
twoway (bar mean_soc_diff_year d_start , bartype(spanning)
ymla(9 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_soc_diff_year ub_soc_diff_year d_middle)
	   (scatter pos1  d_middle, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  title("")
  xtitle("Time Intervals since LUC") 
  ytitle("Absolute ΔSOC (t C ha{sup:-1}year{sup:-1}) ")
yscale(r(-7(1)10))  ylabel(-6(2)10, labels valuelabel ) 
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "Figures/FA3_FtoC_derosa_soc_interval_merged.png",replace
restore



preserve

tempname Lucas_derosa_FC_interval
postfile `Lucas_derosa_FC_interval'  year coef_year coef_Xsoc coef_Xsocsoc  Xsoc_predicted Xsoc2_predicted using Lucas_derosa_FC_interval.dta ,replace
forval i = 1(1)9 {
	reg soc_diff_year year_passed_* year_passedXsoc_* year_passedXsoc2_* , noconstant
	capture drop x 
	gen x = `=_b[year_passedXsoc_`i']'*soc_final*year_passed_`i' if year_passed_`i' ==1 
	sum x
	local Xsoc_predicted `=round(r(mean),0.1)'
	capture drop x2
	gen x2 = `=_b[year_passedXsoc2_`i']'*soc_final*soc_final*year_passed_`i' if year_passed_`i' ==1 
	sum x2
	local Xsoc2_predicted `=round(r(mean),0.1)'
	post `Lucas_derosa_FC_interval' (`i') (`=_b[year_passed_`i']') (`=_b[year_passedXsoc_`i']') (`=_b[year_passedXsoc2_`i']')  (`Xsoc_predicted') (`Xsoc2_predicted')
}
postclose `Lucas_derosa_FC_interval' 
clear
use Lucas_derosa_FC_interval.dta
drop Xsoc*
gen i = 1
reshape wide coef_year coef_Xsoc coef_Xsocsoc, i(i) j(year)
save Lucas_derosa_FC_interval_groupall.dta,replace
restore




/*

gen soc_group = 1 if inlist(nuts0,"IE","FR","BE","NL","LU","DE","UK")
replace soc_group = 2 if inlist(nuts0,"ES","PT","IT","MT","EL","CY","HR")
replace soc_group = 3 if inlist(nuts0,"SE","FI","EE","LV","LT","DK")
replace soc_group = 4 if inlist(nuts0,"PL","CZ","SK","SI","HU","RO","DE","AT","BG")

forval i = 1(1)4 {
preserve

keep if soc_group == `i'
fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(soc_group d_start d_end)

gen lb_soc_diff_year = mean_soc_diff_year - 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))
gen ub_soc_diff_year = mean_soc_diff_year + 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))


gen pos1 = 5
gen obs_soc = string(num_soc_diff_year, "%2.0f")
gen d_middle = (d_start+d_end)/2
insobs 1
replace d_start = 23 if d_start ==.
#delimit;
twoway (bar mean_soc_diff_year d_start , bartype(spanning)
ymla(5 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_soc_diff_year ub_soc_diff_year d_middle)
	   (scatter pos1  d_middle, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  title("Forest to Cropland")
  xtitle("Years since LUC") 
  ytitle("Absolute ΔSOC (t C ha{sup:-1}) ")
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "../Draft/draft_script/FtoC_derosa_soc_interval`i'.png",replace
restore

}

preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(soc_group d_start d_end)
gen duration = d_end - d_start 
gen total_soc_diff  = duration*mean_soc_diff_year
drop if d_start == 20
fcollapse (sum) total_soc_diff , by(soc_group)
rename total_soc_diff deltasoc_CF
save Lucas_derosa_deltasoc_CF_bygroup.dta,replace
restore





