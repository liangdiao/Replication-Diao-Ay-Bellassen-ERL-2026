set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"
* Non-merged time intervals: Figure 4 (CtoG), Figure A2 (OC, CtoG) and CG_soc_cumulative.dta for Table 2.
* Saves to *_nonmerged.dta so the merged-interval data used by FA3/FA4/T3/FA5 is not overwritten.


* collapse by starting and ending year
clear
use Lucas_derosa_CG_cleaned
gen obs = 1
fcollapse (sum)obs (first)tgrass tcrop  (mean)soc_diff_year , by(year_passed timingCG_loose t1 t2)
gen tLUC =  timingCG_loose 
rename soc_diff_year delta_soc

gen start = max(0,t1-tLUC)
gen end = t2 - tLUC



*get all possible interval
keep start end
expand 2, gen(dup)
replace start = end if dup ==1
keep start
bysort start: gen dup = cond(_N==1,0,_n)
keep if dup <=1
drop dup
gen end = start[_n+1]
drop if end==.
gen id_segment = _n
rename start d_start 
rename end d_end
cross  using Lucas_derosa_CG_cleaned.dta
gen start = max(0,t1-tLUC)
gen end = t2 - tLUC

sort d_start d_end start end
gen overlap = 1 if d_start < end & d_end > start
keep if overlap == 1
keep soc_initial soc_final t2 t1 tLUC duration nuts0 oc_diff_year soc_diff_year year_passed start end overlap d_start d_end id_segment
gen obs= 1



* rename time interval
gen year_passed_1 = 0 
replace year_passed_1 = 1 if d_start == 0
gen year_passed_2 = 0 
replace year_passed_2 = 1 if d_start == 1.5
gen year_passed_3 = 0 
replace year_passed_3 = 1 if d_start == 3
gen year_passed_4 = 0 
replace year_passed_4 = 1 if d_start == 4.5
gen year_passed_5 = 0 
replace year_passed_5 = 1 if d_start == 6
gen year_passed_6 = 0 
replace year_passed_6 = 1 if d_start == 7.5
gen year_passed_7 = 0 
replace year_passed_7 = 1 if d_start == 9
gen year_passed_8 = 0 
replace year_passed_8 = 1 if d_start == 10.5
gen year_passed_9 = 0 
replace year_passed_9 = 1 if d_start == 12
gen year_passed_10 = 0 
replace year_passed_10 = 1 if d_start == 14
gen year_passed_11 = 0 
replace year_passed_11 = 1 if d_start == 15
gen year_passed_12 = 0 
replace year_passed_12 = 1 if d_start == 17
gen year_passed_13 = 0 
replace year_passed_13 = 1 if d_start == 20



forval i = 1(1)13 {
	gen year_passedXsoc_`i' = soc_final * year_passed_`i' 
	}
forval i = 1(1)13 {
	gen year_passedXsoc2_`i' = soc_final * soc_final * year_passed_`i'
	}
	
	
save Lucas_derosa_CG_clean_interval_nonmerged.dta,replace

* generate interacted terms
forval i = 1(1)13 {
	gen var`i' = year_passed_`i'
}

eststo c1: reg soc_diff_year var* year_passedXsoc_* year_passedXsoc2_* , noconstant

forval i = 1(1)13 {
	replace var`i' = year_passedXsoc_`i'
}
eststo c2: reg soc_diff_year year_passed_* var* year_passedXsoc2_* , noconstant

forval i = 1(1)13 {
	replace var`i' = year_passedXsoc2_`i'
}
eststo c3: reg soc_diff_year year_passed_* year_passedXsoc_* var* , noconstant
estadd local rmse `=round(e(rmse),0.01)', replace
sum soc_diff_year
estadd local obs `e(N)', replace


label variable  var1 "Year Passed 0     - 1.5"
label variable  var2 "Year Passed 1.5  - 3"
label variable  var3 "Year Passed 3     - 4.5"
label variable  var4 "Year Passed 4.5  - 6"
label variable  var5 "Year Passed 6     - 7.5"
label variable  var6 "Year Passed 7.5  - 9"
label variable  var7 "Year Passed 9     - 10.5"
label variable  var8 "Year Passed 10.5 - 12"
label variable  var9 "Year Passed 12      - 14"
label variable  var10 "Year Passed 14     - 15"
label variable  var11 "Year Passed 15     - 17"
label variable  var12 "Year Passed 17     - 20"
label variable  var13 "Year Passed 20     - 23"

* create cumulative soc change by time interval
preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)
drop if d_start>17
gen group =1
gen interval_soc_diff_year = (d_end-d_start)*mean_soc_diff_year
egen total_soc = sum((d_end-d_start)*mean_soc_diff_year)
bysort group (d_start): gen cumulative_soc_diff_year = sum(interval_soc_diff_year) 
keep d_start d_end cumulative_soc_diff_year
rename cumulative_soc_diff_year cumul_CG
save CG_soc_cumulative.dta,replace
restore


* regression table on non-merged intervals is not reported (Tables A2-A7 use merged intervals, see FA3 scripts)



preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)

gen lb_soc_diff_year = mean_soc_diff_year - 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))
gen ub_soc_diff_year = mean_soc_diff_year + 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))


gen pos1 = 9
gen obs_soc = string(num_soc_diff_year, "%2.0f")
gen d_middle = (d_start+d_end)/2
insobs 1
replace d_start = 23 if d_start ==.
#delimit;
twoway (bar mean_soc_diff_year d_start , bartype(spanning)
ymla(9 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_soc_diff_year ub_soc_diff_year d_middle)
	   (scatter pos1  d_middle, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  title("")
  xtitle("Years since LUC") 
  ytitle("Absolute ΔSOC (t C ha{sup:-1}year{sup:-1}) ")
      yscale(r(-9(1)10))  ylabel(-8(2)10)
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "Figures/F4_CtoG_derosa_soc_interval.png",replace
restore



preserve

fcollapse (mean) mean_oc_diff_year = oc_diff_year (count)num_oc_diff_year = oc_diff_year (sd) sd_oc_diff_year = oc_diff_year , by(d_start d_end)

gen lb_oc_diff_year = mean_oc_diff_year - 1.96*(sd_oc_diff_year/sqrt(num_oc_diff_year))
gen ub_oc_diff_year = mean_oc_diff_year + 1.96*(sd_oc_diff_year/sqrt(num_oc_diff_year))


gen pos1 = 9
gen obs_soc = string(num_oc_diff_year, "%2.0f")
gen d_middle = (d_start+d_end)/2
insobs 1
replace d_start = 23 if d_start ==.
#delimit;
twoway (bar mean_oc_diff_year d_start , bartype(spanning)
ymla(9 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_oc_diff_year ub_oc_diff_year d_middle)
	   (scatter pos1  d_middle, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  title("")
  xtitle("Time Intervals since LUC") 
  ytitle("Absolute ΔOC (g C kg{sup:-1}year{sup:-1}) ")
      yscale(r(-9(1)10))  ylabel(-8(2)10)
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "Figures/FA2_CtoG_derosa_oc_interval.png",replace
restore


/* generate regional estimates

gen soc_group = 1 if inlist(nuts0,"IE","FR","BE","NL","LU","DE","UK")
replace soc_group = 2 if inlist(nuts0,"ES","PT","IT","MT","EL","CY","HR")
replace soc_group = 3 if inlist(nuts0,"SE","FI","EE","LV","LT","DK")
replace soc_group = 4 if inlist(nuts0,"PL","CZ","SK","SI","HU","RO","DE","AT","BG")

forval i = 1(1)4 {
preserve

keep if soc_group == `i'
fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(soc_group d_start d_end)

gen lb_soc_diff_year = mean_soc_diff_year - 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))
gen ub_soc_diff_year = mean_soc_diff_year + 1.96*(sd_soc_diff_year/sqrt(num_soc_diff_year))


gen pos1 = 5
gen obs_soc = string(num_soc_diff_year, "%2.0f")
gen d_middle = (d_start+d_end)/2
insobs 1
replace d_start = 23 if d_start ==.
#delimit;
twoway (bar mean_soc_diff_year d_start , bartype(spanning)
ymla(5 "Obs        ", ang(h) noticks labsize(medsmall))   )
       ( rcap lb_soc_diff_year ub_soc_diff_year d_middle)
	   (scatter pos1  d_middle, ms(none) mla(obs_soc) mlabpos(0) mlabc(blue) )
	   , 
	legend(order(1 "Mean" 2 "95% Confidence Interval"))
  title("Cropland to Grassland")
  xtitle("Time Intervals since LUC") 
  ytitle("Absolute ΔSOC (t C ha{sup:-1}year{sup:-1}) ")
  graphregion(color(white)) bgcolor(white);
#delimit cr
graph export "../Draft/draft_script/CtoG_derosa_soc_interval`i'.png",replace
restore

}

preserve

fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(soc_group d_start d_end)
gen duration = d_end - d_start 
gen total_soc_diff  = duration*mean_soc_diff_year
drop if d_start == 20
fcollapse (sum) total_soc_diff , by(soc_group)
rename total_soc_diff deltasoc_CG
save Lucas_derosa_deltasoc_CG_bygroup.dta,replace
restore



preserve

tempname Lucas_derosa_CG_interval
postfile `Lucas_derosa_CG_interval'  year coef_year coef_Xsoc coef_Xsocsoc  Xsoc_predicted Xsoc2_predicted using Lucas_derosa_CG_interval.dta ,replace
forval i = 1(1)13 {
	reg soc_diff_year year_passed_* year_passedXsoc_* year_passedXsoc2_* , noconstant
	capture drop x 
	gen x = `=_b[year_passedXsoc_`i']'*soc_final*year_passed_`i' if year_passed_`i' ==1 
	sum x
	local Xsoc_predicted `=round(r(mean),0.1)'
	capture drop x2
	gen x2 = `=_b[year_passedXsoc2_`i']'*soc_final*soc_final*year_passed_`i' if year_passed_`i' ==1 
	sum x2
	local Xsoc2_predicted `=round(r(mean),0.1)'
	post `Lucas_derosa_CG_interval' (`i') (`=_b[year_passed_`i']') (`=_b[year_passedXsoc_`i']') (`=_b[year_passedXsoc2_`i']')  (`Xsoc_predicted') (`Xsoc2_predicted')
}
postclose `Lucas_derosa_CG_interval' 
clear
use Lucas_derosa_CG_interval.dta
drop Xsoc*
gen i = 1
reshape wide coef_year coef_Xsoc coef_Xsocsoc, i(i) j(year)
save Lucas_derosa_CG_interval_groupall.dta,replace
restore



