set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"


clear
use GC_soc_cumulative.dta
merge 1:1  d_end using  FC_soc_cumulative.dta
drop _merge
merge 1:1  d_end using  FG_soc_cumulative.dta
drop _merge
merge 1:1  d_end using  CG_soc_cumulative.dta
drop _merge
merge 1:1  d_end using  CF_soc_cumulative.dta
drop _merge
merge 1:1  d_end using  GF_soc_cumulative.dta
drop _merge
format cumul_* %9.1f
drop d_start
rename d_end year
export excel using "Tables/T2.xlsx", replace firstrow(variables)
