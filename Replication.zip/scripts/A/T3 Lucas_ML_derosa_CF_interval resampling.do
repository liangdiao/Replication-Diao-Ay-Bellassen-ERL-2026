set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

* Table 3 confidence intervals: bootstrap on the NON-MERGED time intervals (same curve as Figure 4 / Table 2),
* built by scripts/A/F4 FA2 T2 Lucas_ML_derosa_XX_interval_nonmerged.do

foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
	clear
	use  Lucas_derosa_`x'_clean_interval_nonmerged.dta,replace
	gen seed = 1
	gen soc_interval_`x' = 1
	keep if seed == 0
	keep seed soc_interval_`x'
	save soc_EU_`x'.dta,replace

	forval i  = 1(1)1000{
	set seed `i'
	clear
	use  Lucas_derosa_`x'_clean_interval_nonmerged.dta,replace
	* Perform bootstrap sampling and calculate summary statistics
	bsample 
	fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)
	drop if d_start ==20
	* Compute total SOC for the current sample
	egen total_soc = sum((d_end-d_start)*mean_soc_diff_year)
	keep if _n ==1
	gen seed = `i'
	keep seed total_soc
	rename total_soc soc_interval_`x'
	save temp.dta,replace
	* Append bootstrapped results to the main dataset
	use soc_EU_`x'.dta
	append using temp.dta
	save soc_EU_`x'.dta,replace
	}
}


clear
use soc_EU_GC.dta
merge 1:1 seed using  soc_EU_FC.dta
drop _merge
merge 1:1 seed using  soc_EU_FG.dta
drop _merge
merge 1:1 seed using  soc_EU_CG.dta
drop _merge
merge 1:1 seed using  soc_EU_CF.dta
drop _merge
merge 1:1 seed using  soc_EU_GF.dta
drop _merge

sum soc_*

fcollapse (sd) soc_interval_GC soc_interval_FC soc_interval_FG soc_interval_CG soc_interval_CF soc_interval_GF
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
	replace soc_interval_`x' = soc_interval_`x'*1.96
}
format soc_interval* %9.1f
* the CIs are reported in Tables/T3.xlsx by "T3 Lucas_ML_derosa_interval_summary.do" (reads soc_EU_XX.dta)






/*	
clear 
use  Lucas_derosa_CF_clean_interval.dta,replace
gen seed = 1
gen soc_interval_CF = 1
keep if seed == 0
keep seed soc_interval_CF
save soc_EU_CF.dta,replace

forval i  = 1(1)1000{
set seed `i'
clear
use  Lucas_derosa_CF_clean_interval.dta,replace
bsample 
fcollapse (mean) mean_soc_diff_year = soc_diff_year (count)num_soc_diff_year = soc_diff_year (sd) sd_soc_diff_year = soc_diff_year , by(d_start d_end)
egen total_soc = sum((d_end-d_start)*mean_soc_diff_year)
keep if _n ==1
gen seed = `i'
keep seed total_soc
rename total_soc soc_interval_CF
save temp.dta,replace
use soc_EU_CF.dta
append using temp.dta
save soc_EU_CF.dta,replace
}
*/
