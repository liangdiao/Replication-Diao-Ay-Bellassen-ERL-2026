set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"




************************
*** group ALL ***
************************


clear
use Lucas_cross_grass.dta



rename soc soc_grass
merge 1:1 country using Lucas_cross_crop.dta
drop _merge
rename soc soc_crop
drop temp temp_std prec prec_std sand clay 
gen soc_GtoC_diff = soc_grass-soc_crop

gen soc_group = 1 if inlist(country,"IE","FR","BE","NL","LU","DE","UK")
replace soc_group = 2 if inlist(country,"ES","PT","IT","MT","EL","CY","HR")
replace soc_group = 3 if inlist(country,"SE","FI","EE","LV","LT","DK")
replace soc_group = 4 if inlist(country,"PL","CZ","SK","SI","HU","RO","DE","AT","BG")

cross using Lucas_derosa_FC_cleaned.dta
drop if  country != nuts0

cross using Lucas_derosa_FC_interval_groupall.dta
drop i 

replace dup = 6 if dup ==2
replace dup = 7 if dup ==3
sort point_id dup
by point_id: gen dupp = cond(_N==1,0,_n)
keep if dupp <=1
drop dup dupp

drop if soc_final ==.
egen mean_soc_final = mean(soc_final), by (nuts0)
forval i = 1(1)9 {
	gen year_passed_`i' = coef_year`i'+coef_Xsoc`i'*mean_soc_final+coef_Xsocsoc`i'*mean_soc_final*mean_soc_final 

}



rename year_passed_9 year_passed_140
rename year_passed_8 year_passed_120
rename year_passed_7 year_passed_105
rename year_passed_6 year_passed_90
rename year_passed_5 year_passed_75
rename year_passed_4 year_passed_60
rename year_passed_3 year_passed_45
rename year_passed_2 year_passed_30
rename year_passed_1 year_passed_0




replace year_passed_0 = 3* year_passed_0
replace year_passed_30 = 1.5* year_passed_30
replace year_passed_45 = 1.5* year_passed_45
replace year_passed_60 = 1.5* year_passed_60
replace year_passed_75 = 1.5* year_passed_75
replace year_passed_90 = 1.5* year_passed_90
replace year_passed_105 = 1.5* year_passed_105
replace year_passed_120 = 2* year_passed_120
replace year_passed_140 = 9* year_passed_140


gen sign = 1 if year_passed_0 >=0
replace sign = -1 if year_passed_0 <0
replace year_passed_30 = 0 if year_passed_30 * sign <0 | year_passed_0 ==0
replace year_passed_45 = 0 if year_passed_45 * sign <0 | year_passed_30 ==0
replace year_passed_60 = 0 if year_passed_60 * sign <0 | year_passed_45 ==0
replace year_passed_75 = 0 if year_passed_75 * sign <0 | year_passed_60 ==0
replace year_passed_90 = 0 if year_passed_90 * sign <0 | year_passed_75 ==0
replace year_passed_105 = 0 if year_passed_105 * sign <0 | year_passed_90 ==0
replace year_passed_120 = 0 if year_passed_120 * sign <0 | year_passed_105 ==0
replace year_passed_140 = 0 if year_passed_140 * sign <0 | year_passed_120 ==0

format year_passed* %9.2f
drop coef*

egen change_soc = rowtotal(year_passed_*)
drop obs
gen obs = 1

preserve
fcollapse (mean) change_soc soc_final (sum)obs, by(soc_group)
rename change_soc deltasoc_FC
rename obs obs_FC
drop soc_final
save Lucas_derosa_deltasoc_FC_bygroup.dta,replace
restore

preserve
gen EU = 1
fcollapse (mean) change_soc soc_final (sum)obs, by(EU)
rename change_soc deltasoc_FC
rename obs obs_FC
drop soc_final
save Lucas_derosa_deltasoc_FC_EU.dta,replace
restore

fcollapse (mean) change_soc soc_final (sum)obs, by(nuts0)
rename change_soc deltasoc_FC
rename obs obs_FC
drop soc_final
save FC_crosscountry_group.dta,replace
