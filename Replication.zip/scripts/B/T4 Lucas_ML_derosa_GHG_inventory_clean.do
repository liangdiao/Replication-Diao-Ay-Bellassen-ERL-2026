set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

clear

* Loop for importing and processing data for each category (GtoC, FtoC, etc.)

foreach x in "GtoC" "FtoC" "FtoG" "CtoG" "CtoF" "GtoF"{
clear
import excel "LUC_data.xlsx", sheet("area_`x'") firstrow
    * Calculate the row total for the inventory area

egen inventory_area_`x' = rowtotal(B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	AA	AB	AC	AD	AE	AF	AG)

rename country_code nuts0
keep nuts0 inventory_area_`x'
save inventory_area_`x'.dta,replace
}

* Loop for importing and processing data for soil carbon categories

foreach x in "GtoC" "FtoC" "FtoG" "CtoG" "CtoF" "GtoF"{
clear
import excel "LUC_data.xlsx", sheet("dSOC_`x'") firstrow
    * Calculate the row total for the soil carbon inventory

egen inventory_soc_`x' = rowtotal(B	C	D	E	F	G	H	I	J	K	L	M	N	O	P	Q	R	S	T	U	V	W	X	Y	Z	AA	AB	AC	AD	AE	AF	AG)

rename country_code nuts0
keep nuts0 inventory_soc_`x'
save inventory_soc_`x'.dta,replace
}

* Continue merging other data for each category
clear
use inventory_area_GtoC.dta
merge 1:1 nuts0 using  inventory_soc_GtoC.dta
drop _merge
foreach x in  "FtoC" "FtoG" "CtoG" "CtoF" "GtoF"{
merge 1:1 nuts0 using  inventory_area_`x'
drop _merge
merge 1:1 nuts0 using  inventory_soc_`x'
drop _merge
}
format inventory_* %9.1f
replace nuts0 = "UK" if nuts0 == "GB"
replace nuts0 = "EL" if nuts0 == "GR"


save inventory_panel.dta,replace

* Merge prediction deltas for each category

* country-level dSOC from scripts/B/Lucas_ML_derosa_crosstable_*_interval.do (run via the TA8/TA9 compile scripts)
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
	merge 1:1 nuts0 using `x'_crosscountry_group.dta, nogen
}
replace deltasoc_FC = -12.6
replace deltasoc_CF = 43.8
replace deltasoc_FG = 4.4
replace deltasoc_GF = 30.1
rename inventory_area_GtoC  inventory_area_GC
rename inventory_area_FtoC  inventory_area_FC
rename inventory_area_FtoG  inventory_area_FG
rename inventory_area_CtoG  inventory_area_CG
rename inventory_area_CtoF  inventory_area_CF
rename inventory_area_GtoF  inventory_area_GF
rename inventory_soc_GtoC  inventory_soc_GC
rename inventory_soc_FtoC  inventory_soc_FC
rename inventory_soc_FtoG  inventory_soc_FG
rename inventory_soc_CtoG  inventory_soc_CG
rename inventory_soc_CtoF  inventory_soc_CF
rename inventory_soc_GtoF  inventory_soc_GF

* Generate dynamic values based on area and delta for each category

foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
gen Dynamic_`x' = inventory_area_`x'*deltasoc_`x'/1000
}
* Adjust soil carbon data to match the same units as inventory area

foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
replace inventory_soc_`x' = inventory_soc_`x'/1000
}

drop if nuts0 == "EU"


format inventory_soc_* %9.1f
format Dynamic_* %9.1f

* Collapse the data to aggregate by summing inventory and dynamic values

fcollapse (sum) inventory_area_* Dynamic_*   delta* inventory_soc_*


* Calculate average dynamic values and inventory values per area

foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
gen Dynamic_avg_`x' = Dynamic_`x'/inventory_area_`x'
}


foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
gen inventory_avg_`x' = inventory_soc_`x'*1000/inventory_area_`x'
}
* Calculate total inventory and dynamic values across all categories


egen Inventory_all = rowtotal(inventory_soc_GC inventory_soc_FC inventory_soc_FG inventory_soc_CG inventory_soc_CF inventory_soc_GF)
egen Dynamic_all = rowtotal(Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF)

* Keep only the necessary variables for final analysis

keep Dynamic_GC Dynamic_FC Dynamic_FG Dynamic_CG Dynamic_CF Dynamic_GF inventory_soc_GC inventory_soc_FC inventory_soc_FG inventory_soc_CG inventory_soc_CF inventory_soc_GF
foreach x in "GC" "FC" "FG" "CG" "CF" "GF"{
	rename Dynamic_`x' `x'1
	rename inventory_soc_`x' `x'2
	}

gen id = 1
reshape long GC FC FG CG CF GF, i(id) j(time)
drop id
* Create a new variable to distinguish between dynamic and current inventory

gen Approach = "Dynamic" if time == 1
replace Approach = "Current Inventory" if time == 2
drop time
order Approach GC FC FG CG CF GF
* Calculate total inventory and dynamic values across categories

gen Total = GC +FC+ FG+ CG+ CF+ GF
* Export the final data to an Excel file

export excel using "Tables/T4.xlsx", replace firstrow(variables)
