set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"


clear
use Lucas_derosa_GC_cleaned.dta
* join dataset
gen type = "GC"
append using Lucas_derosa_FC_cleaned.dta
replace type = "FC" if type == ""
append using Lucas_derosa_FG_cleaned.dta
replace type = "FG" if type == ""
append using Lucas_derosa_CG_cleaned.dta
replace type = "CG" if type == ""
append using Lucas_derosa_CF_cleaned.dta
replace type = "CF" if type == ""
append using Lucas_derosa_GF_cleaned.dta
replace type = "GF" if type == ""
append using Lucas_derosa_CCGGFF_cleaned.dta
replace type = "GG" if typeGG != ""
replace type = "FF" if typeFF != ""
replace type = "CC" if typeCC != ""
*: Run summary statistics by 'type' for specific variables

estpost tabstat soc_initial  soc_final  soc_diff_year , c(stat) stat(mean sd n) by (type)
 sum tLUC if tLUC < 2009
  sum tLUC if tLUC < 2000
 
 *: Run and store summary statistics by 'type' for each category

eststo GC: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "GC", c(stat) stat(mean sd n) 
eststo FC: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "FC", c(stat) stat(mean sd n) 
eststo FG: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "FG", c(stat) stat(mean sd n) 
eststo CG: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "CG", c(stat) stat(mean sd n) 
eststo CF: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "CF", c(stat) stat(mean sd n) 
eststo GF: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "GF", c(stat) stat(mean sd n) 
eststo CC: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "CC", c(stat) stat(mean sd n) 
eststo GG: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "GG", c(stat) stat(mean sd n) 
eststo FF: estpost tabstat soc_initial  soc_final  soc_diff_year if type == "FF", c(stat) stat(mean sd n) 

esttab GC FC FG CG CF GF CC GG FF,  main(mean) aux(sd) 
* Export the results to a LaTeX file
#delimit ;
esttab GC FC FG CG CF GF  CC GG FF  using "Tables/T1_summary.tex",replace   main(mean) aux(sd)

 prehead("\hline\hline LUC: & GC & FC & FG & CG & CF& GF & CC & GG & FF\\ ") 

posthead("\hline\hline")
   postfoot("")
cells("mean(fmt(%9.3g))" "sd(par) ") mlabels(none) mgroups(none) unstack nonumbers 
collabels(none) 
keep( soc_initial  soc_final  soc_diff_year )
coeflabels(soc_initial "Initial SOC" soc_final "Final SOC" duration "Duration" soc_diff_year "\$\Delta\$SOC per year" )
eqlabels("GC" "FC" "FG" "CG" "CF" "GF"  "CC" "GG" "FF")  tex;
#delimit cr

