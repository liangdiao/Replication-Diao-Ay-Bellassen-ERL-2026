set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

clear
run "scripts/B/Lucas_ML_derosa_crosstable_CG_interval"
run "scripts/B/Lucas_ML_derosa_crosstable_GF_interval"
run "scripts/B/Lucas_ML_derosa_crosstable_FC_interval"
run "scripts/B/Lucas_ML_derosa_crosstable_FG_interval"
run "scripts/B/Lucas_ML_derosa_crosstable_CF_interval"
run "scripts/B/Lucas_ML_derosa_crosstable_GC_interval"

clear 
use Lucas_ML_derosa_nochange.dta
egen initial_FF = mean(soc_initial) if typeFF !="" , by (nuts0)
egen initial_GG = mean(soc_initial) if typeGG !="" , by (nuts0)
egen initial_CC = mean(soc_initial) if typeCC !="" , by (nuts0)

* generate change in soc under static approach
egen mean_soc = rowmean(soc_2018 soc_2015 soc_2012 soc_2009)
egen soc_GC = mean(mean_soc - ngbr_grass_soc )		if typeCC !="" , by (nuts0)
egen soc_FC = mean(mean_soc - ngbr_forest_soc )		if typeCC !="" , by (nuts0)
egen soc_FG = mean(mean_soc - ngbr_forest_soc )		if typeGG !="" , by (nuts0)
egen soc_CG = mean(mean_soc - ngbr_crop_soc )		if typeGG !="" , by (nuts0)
egen soc_CF = mean(mean_soc - ngbr_crop_soc )		if typeFF !="" , by (nuts0)
egen soc_GF = mean(mean_soc - ngbr_grass_soc )		if typeFF !="" , by (nuts0)

egen permanent_C = mean(mean_soc) if typeCC !="" , by (nuts0)
egen permanent_G = mean(mean_soc) if typeGG !="" , by (nuts0)
egen permanent_F = mean(mean_soc) if typeFF !="" , by (nuts0)


fcollapse (max) initial_FF initial_GG initial_CC soc* permanent*, by (nuts0)
drop soc_2*
*rename nuts0 country
save Lucas_nochange_sum_bycountry.dta,replace



clear
use Lucas_cross_crop.dta

* change LUC
local LUC = "FC"
* merge datasets
rename soc soc_crop
rename obs obs_crop
merge 1:1 country using Lucas_cross_forest.dta
drop _merge
rename soc soc_forest
rename obs obs_forest
merge 1:1 country using Lucas_cross_grass.dta
drop _merge
rename soc soc_grass
rename obs obs_grass
drop temp temp_std prec prec_std sand clay 
keep country soc_crop soc_forest soc_grass


gen soc_group = 1 if inlist(country,"IE","FR","BE","NL","LU","DE","UK")
replace soc_group = 2 if inlist(country,"ES","PT","IT","MT","EL","CY","HR")
replace soc_group = 3 if inlist(country,"SE","FI","EE","LV","LT","DK")
replace soc_group = 4 if inlist(country,"PL","CZ","SK","SI","HU","RO","DE","AT","BG")
* Merge data for different groups
rename country nuts0
merge 1:1 nuts0 using  GC_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  FC_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  FG_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  CG_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  CF_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using  GF_crosscountry_group.dta
drop _merge
merge 1:1 nuts0 using Lucas_nochange_sum_bycountry.dta
drop _merge





* Calculate differences and assign group names

gen diff_GC = deltasoc_GC-soc_GC
gen diff_FC = deltasoc_FC-soc_FC
gen diff_FG = deltasoc_FG-soc_FG
gen diff_CG = deltasoc_CG-soc_CG
gen diff_CF = deltasoc_CF-soc_CF
gen diff_GF = deltasoc_GF-soc_GF
gen group_name = "Atlantic" if soc_group == 1
replace group_name = "Mediterranean" if soc_group == 2
replace group_name = "Scandinavian" if soc_group == 3
replace group_name = "Continental" if soc_group == 4
format deltasoc_* %9.1f
format diff_* %9.1f
format soc_* %9.1f
format deltasoc_* %9.1f

* Export results to Excel

preserve
keep nuts0 deltasoc_GC obs_GC deltasoc_FC obs_FC deltasoc_FG obs_FG deltasoc_CG obs_CG deltasoc_CF obs_CF deltasoc_GF obs_GF
export excel using "Tables/TA9_1.xlsx", replace firstrow(variables)


clear
use Lucas_derosa_deltasoc_GC_bygroup.dta
merge 1:1 soc_group using  Lucas_derosa_deltasoc_FC_bygroup.dta
drop _merge
merge 1:1 soc_group using  Lucas_derosa_deltasoc_FG_bygroup.dta
drop _merge
merge 1:1 soc_group using  Lucas_derosa_deltasoc_CG_bygroup.dta
drop _merge
merge 1:1 soc_group using  Lucas_derosa_deltasoc_CF_bygroup.dta
drop _merge
merge 1:1 soc_group using  Lucas_derosa_deltasoc_GF_bygroup.dta
drop _merge
* Assign group names for new merged data

gen group_name = "Atlantic" if soc_group == 1
replace group_name = "Mediterranean" if soc_group == 2
replace group_name = "Scandinavian" if soc_group == 3
replace group_name = "Continental" if soc_group == 4
format deltasoc_* %9.1f

* Keep necessary variables and order them

keep group_name deltasoc_GC obs_GC deltasoc_FC obs_FC deltasoc_FG obs_FG deltasoc_CG obs_CG deltasoc_CF obs_CF deltasoc_GF obs_GF 
order group_name deltasoc_GC obs_GC deltasoc_FC obs_FC deltasoc_FG obs_FG deltasoc_CG obs_CG deltasoc_CF obs_CF deltasoc_GF obs_GF 
export excel using "Tables/TA9_2.xlsx", replace firstrow(variables)

* Merge European data


clear
use Lucas_derosa_deltasoc_GC_EU.dta
merge 1:1 EU using  Lucas_derosa_deltasoc_FC_EU.dta
drop _merge
merge 1:1 EU using  Lucas_derosa_deltasoc_FG_EU.dta
drop _merge
merge 1:1 EU using  Lucas_derosa_deltasoc_CG_EU.dta
drop _merge
merge 1:1 EU using  Lucas_derosa_deltasoc_CF_EU.dta
drop _merge
merge 1:1 EU using  Lucas_derosa_deltasoc_GF_EU.dta
drop _merge
export excel using "Tables/TA9_3.xlsx", replace firstrow(variables)
restore

