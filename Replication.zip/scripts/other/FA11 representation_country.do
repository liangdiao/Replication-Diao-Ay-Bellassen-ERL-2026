set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"


clear
use Lucas_derosa_GC_cleaned.dta
* join dataset
gen type = "GC"
append using Lucas_derosa_FC_cleaned.dta
replace type = "FC" if type == ""
append using Lucas_derosa_FG_cleaned.dta
replace type = "FG" if type == ""
append using Lucas_derosa_CG_cleaned.dta
replace type = "CG" if type == ""
append using Lucas_derosa_CF_cleaned.dta
replace type = "CF" if type == ""
append using Lucas_derosa_GF_cleaned.dta
replace type = "GF" if type == ""
append using Lucas_derosa_CCGGFF_cleaned.dta
replace type = "GG" if typeGG != ""
replace type = "FF" if typeFF != ""
replace type = "CC" if typeCC != ""
*: Run summary statistics by 'type' for specific variables
drop if inlist(type,"GG","FF","CC" )


gen  obs_country =  1
fcollapse (sum)obs_country, by(nuts0)
keep nuts0 obs_country
save temp.dta,replace



clear
use Lucas_ML_merged.dta

replace oc_2012 =. if oc_2012 == -999
replace clay_2009 ="" if clay_2009 == "NA"
replace sand_2009 ="" if sand_2009 == "NA"
replace caco3_2018 ="" if caco3_2018 == "NA"
replace caco3_2018 ="0" if caco3_2018 == "<  LOD"
replace caco3_2012 ="0" if caco3_2012 == "<0.5"

destring clay_2009,replace
destring sand_2009,replace
destring caco3_2018,replace
destring caco3_2012,replace



gen clay =.
replace clay = clay_2009/100 if clay_2009 !=.
replace clay = clay_2015/100 if clay_2015 !=.
replace clay = clay_2012/100 if clay_2012 !=.


gen sand =.
replace sand = sand_2009/100 if sand_2009 !=.
replace sand = sand_2015/100 if sand_2015 !=.
replace sand = sand_2012/100 if sand_2012 !=.


gen bd_2018 = 0.80806 +0.823844*exp(-0.27993*oc_2018)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2015 = 0.80806 +0.823844*exp(-0.27993*oc_2015)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2012 = 0.80806 +0.823844*exp(-0.27993*oc_2012)+(0.0014065*sand)-(0.0010299*clay)
gen bd_2009 = 0.80806 +0.823844*exp(-0.27993*oc_2009)+(0.0014065*sand)-(0.0010299*clay)



gen coarse =.
replace coarse = coarse_2009/100 if coarse_2009 !=.
replace coarse = coarse_2015/100 if coarse_2015 !=.
replace coarse = coarse_2012/100 if coarse_2012 !=.

gen old_bd_fine_2018 = bd_2018*(1-coarse) *2.6/(2.6-bd_2018* coarse)
gen old_bd_fine_2015 = bd_2015*(1-coarse) *2.6/(2.6-bd_2015* coarse)
gen old_bd_fine_2012 = bd_2012*(1-coarse) *2.6/(2.6-bd_2012* coarse)
gen old_bd_fine_2009 = bd_2009*(1-coarse) *2.6/(2.6-bd_2009* coarse)

gen raster_bd_fine = bd_raster_1020*(1-coarse) *2.6/(2.6-bd_raster_1020* coarse)

gen old_coarse_volumn_2018 = coarse/(2.6/old_bd_fine_2018+(1-2.6/old_bd_fine_2018)*coarse)
gen old_coarse_volumn_2015 = coarse/(2.6/old_bd_fine_2015+(1-2.6/old_bd_fine_2015)*coarse)
gen old_coarse_volumn_2012 = coarse/(2.6/old_bd_fine_2012+(1-2.6/old_bd_fine_2012)*coarse)
gen old_coarse_volumn_2009 = coarse/(2.6/old_bd_fine_2009+(1-2.6/old_bd_fine_2009)*coarse)

gen coarse_volumn = coarse/(2.6/raster_bd_fine+(1-2.6/raster_bd_fine)*coarse)



drop if oc_2009>160 & oc_2009 !=.
drop if oc_2012>160 & oc_2012 !=.
drop if oc_2015>160 & oc_2015 !=.
drop if oc_2018>160 & oc_2018 !=.

* caco3 unit is g per kg, filter and caco3 >5% (50g per kg) according to DeRosa 2023
drop if caco3_2009>50 & caco3_2009 !=.
drop if caco3_2012>50 & caco3_2012 !=.
drop if caco3_2015>50 & caco3_2015 !=.
drop if caco3_2018>50 & caco3_2018 !=.

keep if nuts0 !=""

gen obs_orig = 1 
fcollapse (sum)obs_orig, by (nuts0)
merge 1:1 nuts0 using temp.dta
gen area = . 
replace area = 2586   if nuts0 == "LU"
replace area = 69825  if nuts0 == "IE"
replace area = 9251   if nuts0 == "CY"
replace area = 338440 if nuts0 == "FI"
replace area = 56594  if nuts0 == "HR"
replace area = 438574 if nuts0 == "SE"
replace area = 41543  if nuts0 == "NL"
replace area = 244381 if nuts0 == "UK"
replace area = 506009 if nuts0 == "ES"
replace area = 301958 if nuts0 == "IT"
replace area = 93025  if nuts0 == "HU"
replace area = 30528  if nuts0 == "BE"
replace area = 357581 if nuts0 == "DE"
replace area = 83878  if nuts0 == "AT"
replace area = 131957 if nuts0 == "EL"
replace area = 238298 if nuts0 == "RO"
replace area = 49035  if nuts0 == "SK"
replace area = 42947  if nuts0 == "DK"
replace area = 633109 if nuts0 == "FR"
replace area = 110994 if nuts0 == "BG"
replace area = 312679 if nuts0 == "PL"
replace area = 92225  if nuts0 == "PT"
replace area = 78871  if nuts0 == "CZ"
replace area = 45399  if nuts0 == "EE"
replace area = 64594  if nuts0 == "LV"
replace area = 65286  if nuts0 == "LT"
replace area = 20273  if nuts0 == "SI"
replace area = 315    if nuts0 == "MT"

replace area = area /1000
gen percentage = obs_country / area

gen nuts0_label = nuts0
replace nuts0_label = "" if area< 110

twoway (scatter obs_orig area, mcolor(navy) msize(vsmall) mlabel(nuts0_label) mlabposition(3) mlabsize(small) mlabcolor(navy) mlabgap(2)) ///
       (lfit obs_orig area, lcolor(red) lwidth(medium)), ///
    title("", size(medium)) ///
    xtitle("Country Area (1000km²)") ///
    ytitle("Number of Observations (all LUCs)") ///
      legend(order(1 "Countries" 2 "Linear Fit") rows(1) position(6)) ///
///
    note("Each point represents an EU member state. Labels show NUTS-0 country codes.", size(vsmall))

graph export "Figures/FA11_representation.png", replace width(1200)
