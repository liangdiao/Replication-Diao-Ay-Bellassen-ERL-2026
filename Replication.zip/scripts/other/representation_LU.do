set more off
graph drop _all
clear all
cd "/Users/liang/Dropbox/SOC/Data analysis/Replicate"

clear 
use "scripts/GHG Inventory/inventory_panel.dta"


fcollapse (sum) inventory_area_GtoC inventory_area_FtoC inventory_area_FtoG inventory_area_CtoG inventory_area_CtoF inventory_area_GtoF

/*
inventory_area_GtoC	inventory_area_FtoC	inventory_area_FtoG	inventory_area_CtoG	inventory_area_CtoF	inventory_area_GtoF
30477.1	1704.7	2534.2	41864.4	7440.6	16769.0

*/

clear
use Lucas_derosa_GC_cleaned.dta
* join dataset
gen type = "GC"
append using Lucas_derosa_FC_cleaned.dta
replace type = "FC" if type == ""
append using Lucas_derosa_FG_cleaned.dta
replace type = "FG" if type == ""
append using Lucas_derosa_CG_cleaned.dta
replace type = "CG" if type == ""
append using Lucas_derosa_CF_cleaned.dta
replace type = "CF" if type == ""
append using Lucas_derosa_GF_cleaned.dta
replace type = "GF" if type == ""
append using Lucas_derosa_CCGGFF_cleaned.dta
replace type = "GG" if typeGG != ""
replace type = "FF" if typeFF != ""
replace type = "CC" if typeCC != ""
*: Run summary statistics by 'type' for specific variables
drop if inlist(type,"GG","FF","CC" )


* letter group E: crop B: forest C: grass
gen  obs_country =  1
fcollapse (sum)obs_country, by(type)
gen area_inventory = 0
replace area_inventory = 30477.1 if type == "GC"
replace area_inventory = 1704.7 if type == "FC"
replace area_inventory = 2534.2 if type == "FG"
replace area_inventory = 41864.4 if type == "CG"
replace area_inventory = 7440.6 if type == "CF"
replace area_inventory = 16769.0 if type == "GF"

gen percentage = obs_country/area_inventory

